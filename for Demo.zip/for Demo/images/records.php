<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Student Registration</title>
<style type="text/css">
<!--
.style15 {
	color: #FFFF00;
	font-size: 10;
	font-family: Geneva, Arial, Helvetica, sans-serif;
}
.style28 {
	font-size: x-large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style29 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: large;
	font-weight: bold;
}
body {
	background-image: url(bg/cloud.gif);
}
.style31 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: xx-large;
}
.style32 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: x-large; }
.style33 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style34 {
	font-size: xx-large;
	color: #FFFF00;
}
.style35 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style38 {font-size: 12px}
.style39 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
.style40 {color: #FFFF00}
.style41 {font-size: 14px}
.style46 {color: #0000FF; font-size: large;}
.style47 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #0000FF;
	font-weight: bold;
	font-size: 12px;
}
.style48 {
	font-size: 14px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style49 {font-weight: bold}
.style51 {font-size: 12px; font-weight: bold; }
-->
</style>
</head>
<?php
mysql_connect("localhost", "root", "") or die(mysql_error()); 
mysql_select_db("students") or die(mysql_error());

ini_set("post_max_size","128M");
ini_set("session.gc_maxlifetime","10800"); 
ini_set("upload_max_filesize", "200M");
 
if(isset($_POST['Submit'])) 
{
$studnumber = $_POST['textfield'];
$firstname= $_POST['textfield2'];
$mi= $_POST['textfield3'];
$lastname = $_POST['textfield4'];
$gender = $_POST['radiobutton'];
$course = $_POST['textfield5'];
$address= $_POST['textarea'];
$contact= $_POST['textfield7'];

if($studnumber=="") {
?>
<SCRIPT Language=Javascript>
<!--
	alert("Empty data!");
// End -->
</SCRIPT>
<SCRIPT Language=Javascript>
<!--
	history.back();
// End -->
</SCRIPT>
<?php
} 
$result = mysql_query(" SELECT * from wad311exer2 WHERE studentnumber = '$studnumber' AND firstname = '$firstname' AND lastname='$lastname' " )or die('Error, query failed. ' . mysql_error()); 
		
$row = mysql_fetch_array($result);
$count = mysql_num_rows($result);

if($count==0) {
$sql = "INSERT INTO wad311exer2 (studentnumber,firstname,mi,lastname,gender,course,address,contactnumber)  VALUES('$studnumber','$firstname','$mi','$lastname','$gender','$course','$address','$contact' )";

mysql_query($sql) or die('Error, query failed. ' . mysql_error()); 

} else {
?>
<SCRIPT Language=Javascript>
<!--
	alert("Record Already exists. Wag na makulit ha!");
// End -->
</SCRIPT>
<SCRIPT Language=Javascript>
<!--
 location.href="view.php";
// End -->
</SCRIPT>
<?php

 }
}


?>

<body><center>
  <table width="956" border="0" align="center" cellspacing="4" bgcolor="#FFFFFF">
  <tr>
    <td width="174" height="146"><img src="ama logo.png" width="174" height="144" /></td>
    <td width="772" background="bg/background.jpg"><div align="center" class="style28">
      <p><span class="style34">AMA CLC Morayta</span> <span class="style40"><br />
          <span class="style29">Web Applications Development </span></span><br />
      </p>
      </div></td>
  </tr>
  <tr>
    <td height="549" colspan="2" align="center" valign="top" background="bg/notepad-back.gif"><table width="925" border="0" cellpadding="0" cellspacing="1">
      <tr>
        <td width="703" height="408" align="center"><p class="style32">Students Registration</p>
          <form id="form1" name="form1" method="post" enctype="multipart/form-data" action="<?php $_PHP_SELF ?>">
            <table width="607" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
              <tr>
                <td width="129" height="37" class="style48"><span class="style41 style35  style46"><span class="style51">Student No </span></span></td>
                <td width="478"><label> </label>
                    <label>
                    <input name="textfield" type="text" id="textfield" size="50" />
                    </label>
                    <label></label></td>
              </tr>
              <tr>
                <td class="style48"><span class="style41 style35  style46"><span class="style51">Firstname</span></span></td>
                <td><label> </label>
                    <label>
                    <input name="textfield2" type="text" id="textfield2" size="50" />
                    </label>
                    <label></label></td>
              </tr>
              <tr>
                <td height="29" class="style48"><span class="style41 style35  style46"><span class="style51">MI</span></span></td>
                <td><label> </label>
                    <label>
                    <input name="textfield3" type="text" id="textfield3" size="50" />
                    </label>
                    <label></label></td>
              </tr>
              <tr>
                <td class="style48"><span class="style47">Last Name </span></td>
                <td><label> </label>
                    <label>
                    <input name="textfield4" type="text" id="textfield4" size="50" />
                    </label>
                    <label></label></td>
              </tr>
              <tr>
                <td height="32" class="style48"><span class="style41 style35  style46"><span class="style51">Course</span></span></td>
                <td><input name="textfield5" type="text" id="textfield5" size="60" /></td>
              </tr>
              <tr>
                <td height="29" class="style48"><span class="style41 style35  style46"><span class="style51">Gender</span></span></td>
                <td><input name="radiobutton" type="radio" value="Male" checked="checked" />
                  Male
                  <label>
          <input name="radiobutton" type="radio" value="Female" checked="checked" />
                    Female</label></td>
              </tr>
              <tr>
                <td height="81" class="style48"><span class="style41 style35  style46"><span class="style51">Address</span></span></td>
                <td><label>
                  <textarea name="textarea" cols="60" rows="4"></textarea>
                </label></td>
              </tr>
              <tr>
                <td height="33" class="style48"><span class="style41 style35  style46"><span class="style51">CP # </span></span></td>
                <td><input name="textfield7" type="text" id="textfield7" size="60" /></td>
              </tr>
            </table>
            <input type="submit" name="Submit" value="  Save  " />
            <input type="submit" name="Submit2" value="Cancel" />
          </form>          </td>
        <td width="206" background="bg/yellow10.jpg">&nbsp;</td>
      </tr>
    </table>
	  <span class="style31">Students Masterlist </span><br /><center>
      <table width="908" height="64" border="0" cellpadding="1" cellspacing="1" bordercolor="#99CCCC" align="right">
        <tr bgcolor="#000000">
          <td width="105" height="28"><span class="style15">Student Number </span></td>
          <td width="101"><span class="style15">First Name </span></td>
          <td width="30"><div align="center"><span class="style15">MI</span></div></td>
          <td width="106"><span class="style15">Last Name</span></td>
          <td width="89"><span class="style15">Gender</span></td>
          <td width="84"><span class="style15">Course</span></td>
          <td width="149"><span class="style15">Address</span></td>
          <td width="123"><span class="style15">CP # </span></td>
          <td width="93"><div align="center"><span class="style15">Action</span></div></td>
        </tr>
        <?php
		   $result = mysql_query(" SELECT * from wad311exer2 "); 	
	   	  while($row = mysql_fetch_array( $result )) {
		?>
        <tr bordercolor="#996633" bgcolor="#FFCCFF">
          <td height="22"><span class="style49 style35 style38">&nbsp;<?php echo $row['studentnumber']; ?></span></td>
          <td><span class="style49 style35 style38">&nbsp;<?php echo $row['firstname']; ?></span></td>
          <td><div align="center" class="style39"><span class="style49">&nbsp;<?php echo $row['mi']; ?></span></div></td>
          <td><span class="style49 style35 style38">&nbsp;<?php echo $row['lastname']; ?></span></td>
          <td><span class="style49 style35 style38">&nbsp;<?php echo $row['gender']; ?></span></td>
          <td><span class="style49 style35 style38">&nbsp;<?php echo $row['course']; ?> </span></td>
          <td><span class="style49 style35 style38">&nbsp;<?php echo $row['address']; ?></span></td>
          <td><span class="style49 style35 style38">&nbsp;<?php echo $row['contactnumber']; ?></span></td>
          <td><div align="center" class="style39"><span class="style49">9.	<a href="delete.php?id=<?php echo $row['studentnumber']; ?>"></a></span></td>
        </tr>
        <?php
		 }
 		?>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><span class="style33">Copyright (R) [your name] Follow us on Twitter * Like us on Facebook </span></td>
  </tr>
</table>
</center>
<h1>&nbsp;</h1>
</body>
</html>
