<?php
mysql_connect("localhost", "root", "") or die(mysql_error()); 
mysql_select_db("students") or die(mysql_error());

$id=$_REQUEST['id'];

$result = mysql_query(" SELECT * FROM wad311exer2 WHERE studentnumber ='$id' ") or die('Error, query failed. ' . mysql_error());
$count = mysql_num_rows($result);

if($count!=0) {

  mysql_query(" DELETE FROM wad311exer2 where studentnumber ='$id' ")  or die('Error, query failed. ' . mysql_error());

?>
<SCRIPT language=JavaScript>
<!--
    alert("Record has been deleted from database!");
//  End -->
</script>			 

<SCRIPT language=JavaScript>
<!--
 location.href="records.php";
//  End -->
</script>			 
<?php
}
?>
