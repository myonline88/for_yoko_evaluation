
<style type="text/css">
<!--
.style2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
.style6 {
	font-size: 14px;
	font-weight: bold;
}
.style7 {
	font-size: 10px;
	font-weight: bold;
}
.style22 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-weight: bold; }
.style24 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; font-weight: bold; }
-->
</style>
<body>	
<center>
<table width="100%" border="0" cellpadding="3" cellspacing="0" bordercolor="#FFFFFF">
  <tr>
    <td height="495" align="center" valign="middle" bgcolor="#FFFFFF">
      <?php include("slider.php"); ?>
    </td>
  </tr>
  <tr>
    <td height="384" align="left" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="1" cellpadding="3">
      <tr>
        <td height="44" colspan="3" align="left" valign="bottom"><span class="style2">Why choose our services? </span> <strong class="style5">We have catered to several clients in different locations around the country. We have completed drilling services to different private companies and government institutions.</strong></td>
        </tr>
      <tr>
        <td width="32%" height="334" align="center" valign="top"><img src="fin_projects/ayala_mall_fridgeway.png" width="423" height="286"><br>
          <span class="style3">Concrete Pouring using Ready Concrete mixer </span></td>
        <td width="34%" align="center" valign="top"><img src="fin_projects/pinaglabanan.png" width="431" height="287"><br>
          <span class="style5"><span class="style6">Micro Pile, Drilling, Boring, Soil Test, Rebar Cage, Spiral, Tremie pipe fabrication</span></span></td>
        <td width="34%" align="center" valign="top"><img src="img/tikling_overpass.png" width="440" height="284"><br>
          <span class="style5"><span class="style6">Sample finished constructions and many more..  </span><span class="style7"></span></span></td>
      </tr>
      <tr>
        <td height="44" colspan="3" align="left" valign="top"><span class="style22">This website is a prototype for the following Web Application : </span><span class="style24">This web application is used for record keeping for Adding, Updating, Viewing and Deleting records. Using MySQL software that can be easily deployed to different web domain </span></td>
        </tr>
      <tr>
        <td height="91" align="left" valign="top"> <p><span class="style24">Online Invetory :</span><br>
            <span class="style5">Designed to monitor the flow of outgoing and incoming purchases, deployment of tools, machines, accessories needed for everyday operations. It keeps tracks of who issued it, to whom it was issued, its state and condition, the quantity of items deployed and number of items remain. It employs records search based on a selected criteria to  find the items fast and makes processing easy.<br>
</span></p>
          </td>
        <td align="left" valign="top"><p class="style5"><strong>Time keeping/Payroll, Employee Records:</strong><br>
          It can be also used as a timekeeping tools for employees, constructions workers, engineers, driller, drivers and everyone working in the company. This timekeeping function is then used to prepare payroll for easy access to employees payroll based on given selected payroll period.
        It keeps tracks of their timeins, timeouts, overtime and calculate the based on ther rate and number of days worked. </p>
          </td>
        <td align="left" valign="top"><span class="style5"><strong>Purchases, Orders, Suppliers:</strong><br> 
          Keeps records for retrieving, addding new, editing, displaying and deleting. Administrator can prepare reports for specific criterias such as Dates, Suppliers &amp; Products, Suppliers and Dates or any criterias deemed necessary to produce reports as needed by the Managers of CEO for business presentation.</span></td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
</html>
