1. please deploy the files in an Apache or EasyPHP web server
2. Import the newA.sql database to MySQL phpMyadmin
3. create an Alias, load it on a browser
4. Use username: ariel   and password: clemente

I have temporarily included the payroll_master.php for your evaluation.
This webpages (web app) is a prototype of the web application I have made  