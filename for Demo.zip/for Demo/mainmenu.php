
<style type="text/css">
body {
	font-family: Microsoft Sans Serif;
	font-size: 12px;
	margin: 0px;
}

nav ul ul {
	display: none;
}

	nav ul li:hover > ul {
		display: block;
	}
nav ul {
	background: linear-gradient(top, #efefef 0%, #bbbbbb 100%);  
	box-shadow: 0px 0px 11px rgba(0,0,0,0.2);
	padding: 0 10px;
	list-style: none;
	position: relative;
	display: inline-table;
}
	nav ul:after {
		content: ""; clear: both; display: block;
	}

nav ul li {
	float: left;
}
	nav ul li:hover {
		background: -moz-linear-gradient(top, #4f5964 0%, #5f6975 50%);
		background: -webkit-linear-gradient(top, #4f5964 0%,#5f6975 50%);
	}
		nav ul li:hover a {
			color: #ffffff;
			float: left;
		}
	
	nav ul li a {
		display: block; padding: 10px 15px;
		color: #000000; text-decoration: none;
	}

nav ul ul {
	background: #5f6975; border-radius: 2px; padding: 0;
	position: absolute; top: 100%;
}
	nav ul ul li {
		float: none; 
		border-top: 1px solid #6b727c;
		border-bottom: 1px solid #575f6a;
		position: relative;
	}
		nav ul ul li a {
			padding: 9px 10px;		color: #fff;
		}	
			nav ul ul li a:hover {
				background: #9999CC;
			}


nav ul ul ul {
	position: absolute; left: 100%; top:0;
}
.style1 {font-family: Verdana, Arial, Helvetica, sans-serif}
</style>
	

<?php
@session_start();
?>

<nav>
	<ul>
<span class="style10 style26">
		<li><span class="style1"><a href="index.php">&nbsp;Home&nbsp;</a>
		  </span>
		  <ul class="style1">
			  <li><a href="logout.php" target="myiframe">Logout</a></li>								    
			  <li><a href="contactus.php" target="myiframe">Contact Us</a></li>
		  </ul>
		</li>
		<span class="style1">
		<?php if(@$_SESSION['accesslevel']=="Admin") { ?>
		</span>
		<li class="style1"><a href="">Inventory</a>
			<ul>
				<li><a href="suppliers.php">Suppliers</a></li>								    
				<li><a href="price_quotations.php">Price Quotations</a></li>								    
				<li><a href="stocks.php">Stocks</a></li>								    
				<li><a href="joas.php">J.O.A.S</a></li>								    
			</ul>
		</li>
		<li class="style1"><a href="payroll_master.php">Payroll Preparation</a>
			<ul>
				<li><a href="employees.php">Employees</a></li>
			</ul>
		</li>	
		<li class="style1"><a href="projects.php">Projects </a></li>			
		<li class="style1"><a href="purchase_orders.php">Purchases</a>
			<ul>
				<li><a href="purchases.php">Purchases Report</a></li>				    
				<li><a href="sellers_masterlist.php">Suppliers Masterlist</a></li>				    
			</ul>
		</li>
		<li class="style1"><a href="expenses.php">Expenses</a></li>
		<li class="style1"><a href="receivables.php">Receivables</a></li>
 	    <li class="style1"><a href="payables.php">Payables</a>
			<ul>
				<li><a href="payables2.php">Payables Report</a></li>				    
			</ul>
		</li>
        <span class="style1">
        <?php } else { ?>
		</span>
        <li class="style1"><a href="whatwedo.php">Our Services</a></li>
        <li class="style1"><a href="gallery.php">Gallery</a></li>
		<li class="style1"><a href="contactus.php">Contact Us</a></li>
		<li class="style1"><a href="aboutus.php">About Us</a>
		  <ul>
				<li><a href="aboutus.php">About Us</a></li>				    
				<li><a href="history.php">History</a></li>				    
				<li><a href="locationmap.php">Location</a></li>				    
		  </ul>
	  </li>
	<?php
	//mysqli_close($conn);
	}
	?>
	</ul>
