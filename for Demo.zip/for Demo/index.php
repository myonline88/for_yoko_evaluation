<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="scripts/dynifs.js"></script> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>New-A Construction: Home</title>
<style type="text/css">
<!--
.style26 {font-size: 12px}
.style47 {
	font-size: 12px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #000000;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style50 {font-size: 10px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #000000; }
.style52 {color: #FFFFFF}
-->
</style>
</head>
<SCRIPT Language = Javascript>
<!--
function validateMe() {
frm1 = document.form1;
if(frm1.textname.value == '') {
alert("Please enter your name");
frm1.textname.focus();
return false;
}

// next item to be validated
return true;
}
// End -->
</SCRIPT>

<?php 
// connection here
@session_start();
include("webconnect.php");

// mysql_connect("localhost", "root", "") or die(mysql_error()); 
// mysql_select_db("students") or die(mysql_error());

$dateposted = date('M-d,Y  h:m:s');

//$result = mysql_query("select * from comment where status = 'approved' ");
//$datep=date('M d,Y H:m:s');


// prepare the variables from the $_POSTing 

// save the record using INSERT command

// mysql_query($sql) or die('Error, query failed. ' . mysql_error()); 

?>

<body>	
<center>
<table width="99%" border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td height="50" align="center" valign="top"><?php include("navmenu.php"); ?></td>
  </tr>
</table>
<table width="99%" border="0" cellpadding="0" cellspacing="0">
  <tr class="style26">
    <td height="269" align="left" valign="top" bgcolor="#E7EEF8">
	<table width="100%" height="264" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="225" align="center" valign="top"><?php include("home.php"); ?></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="2" align="left" valign="top" background="bg/Bkgrnd66.jpeg"></td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td height="56" align="center" background="bg/body_bg.gif"><table width="965" border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td><table width="100%" border="0" cellspacing="4" cellpadding="1">
          <tr>
            <td width="53%" align="left" valign="middle" background="bg/body_bg.gif"><span class="style50"> <img src="buttons/001_20.png" width="34" height="34" align="left" /> webmaster: Jose Ariel P. Clemente : 2020 </span></td>
            <td width="44%" align="left" valign="top" background="bg/body_bg.gif"><span class="style47"><span class="style52"> <img src="images/computer1.gif" width="31" height="41" align="left" /><br />
            </span></span></td>
            <td width="3%" background="bg/body_bg.gif">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
