-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2021 at 06:40 AM
-- Server version: 5.6.15-log
-- PHP Version: 5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `newa`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `names` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `comment` text COLLATE latin1_general_ci NOT NULL,
  `remarks` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `dateposted` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `employeenumber` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `firstname` varchar(35) COLLATE latin1_general_ci NOT NULL,
  `mi` varchar(4) COLLATE latin1_general_ci NOT NULL,
  `lastname` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(9) COLLATE latin1_general_ci NOT NULL,
  `position` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `birthday` date NOT NULL,
  `salary_rate` float NOT NULL,
  `datehired` date NOT NULL,
  `SSS_No` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `TIN` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `pagibig_no` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `phealth_no` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `wtax` float NOT NULL,
  `sss` float NOT NULL,
  `pagibig` float NOT NULL,
  `phealth` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=113 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employeenumber`, `firstname`, `mi`, `lastname`, `address`, `gender`, `position`, `birthday`, `salary_rate`, `datehired`, `SSS_No`, `TIN`, `pagibig_no`, `phealth_no`, `wtax`, `sss`, `pagibig`, `phealth`) VALUES
(71, '', 'Michael Virden', '-', 'Virden', 'Circulo Verde', 'Male', 'Helper', '0000-00-00', 350, '0000-00-00', '', '', '', '', 42, 0, 0, 0),
(72, '', 'Daniel Senobio', '-', 'Senobio', 'Circulo Verde', 'Male', 'Helper', '0000-00-00', 550, '0000-00-00', '', '', '', '', 42, 0, 0, 0),
(70, '', 'Marcelino Rupin', '-', 'Rupin', 'Circulo Verde', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(68, '', 'Gerald Nitullano', '-', 'Nitullano', 'Circulo Verde', 'Male', 'Helper', '0000-00-00', 450, '0000-00-00', '', '', '', '', 54, 0, 0, 0),
(69, '', 'Jonie Isag', '-', 'Isag', 'Circulo  Verde', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(67, '', 'Romeo Ibale, Jr', '-', 'Ibale, Jr', 'Circulo Verde', 'Male', 'helper', '0000-00-00', 650, '0000-00-00', '', '', '', '', 78, 0, 0, 0),
(73, '', 'Elesio Domalina', '-', 'Domalina', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 650, '0000-00-00', '', '', '', '', 78, 0, 0, 0),
(74, '', 'Sem Barison', '-', 'Barison', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 650, '0000-00-00', '', '', '', '', 78, 0, 0, 0),
(75, '', 'Eric Cabca', '-', 'Cabca', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(76, '', 'Ronald Rabaca', '-', 'Rabaca', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(77, '', 'Alvin Santelices', '-', 'Santelices', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(78, '', 'Nappy Nacar', '-', 'Nacar', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(79, '', 'Aldren Wares', '-', 'Wares', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 350, '0000-00-00', '', '', '', '', 42, 0, 0, 0),
(80, '', 'Ronnie Marapoc', '-', 'Marapoc', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(81, '', 'Michael Soposo', '-', 'Soposo', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 650, '0000-00-00', '', '', '', '', 78, 0, 0, 0),
(82, '', 'John Erwin Barison', '-', 'Barison', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 350, '0000-00-00', '', '', '', '', 42, 0, 0, 0),
(83, '', 'Jerwin Seposo', '-', 'Seposo', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 350, '0000-00-00', '', '', '', '', 42, 0, 0, 0),
(84, '', 'Wilmar Soposo', '-', 'Soposo', 'Malabon Sports Complex', 'Male', 'Helper', '0000-00-00', 350, '0000-00-00', '', '', '', '', 42, 0, 0, 0),
(85, '', 'Jose Lunar Navarro', '-', 'Navarro', 'Riverside', 'Male', 'Helper', '0000-00-00', 600, '0000-00-00', '', '', '', '', 72, 0, 0, 0),
(86, '', 'Joseph Ansuyon', '-', 'Ansuyon', 'Riverside', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(87, '', 'Richard Ansuyon', '-', 'Ansuyon', 'Riverside', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(88, '', 'Joey Ansuyon', '-', 'Ansuyon', 'Riverside', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(89, '', 'Ronald Puod', '-', 'Puod', 'Riverside', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(90, '', 'Jessie Andrada', '-', 'Andrada', 'PASAY', 'Male', 'Helper', '0000-00-00', 500, '0000-00-00', '', '', '', '', 60, 0, 0, 0),
(91, '', 'Ivan Ramos', '-', 'Ramos', 'PASAY', 'Male', 'Helper', '0000-00-00', 500, '0000-00-00', '', '', '', '', 60, 0, 0, 0),
(92, '', 'Joevanie Inday', '-', 'Inday', 'PASAY', 'Male', 'Helper', '0000-00-00', 650, '0000-00-00', '', '', '', '', 78, 0, 0, 0),
(93, '', 'Ruel Misagal', '-', 'Misagal', 'PASAY', 'Male', 'Back Hoe Op', '0000-00-00', 750, '0000-00-00', '', '', '', '', 90, 0, 0, 0),
(94, '', 'Arnold Caniete', '-', 'Caniete', 'PASAY', 'Male', 'Helper', '0000-00-00', 500, '0000-00-00', '', '', '', '', 60, 0, 0, 0),
(95, '', 'Ernesto Cruz', '-', 'Cruz', 'BACK HOE', 'Male', 'Back Hoe Op', '0000-00-00', 833.34, '0000-00-00', '', '', '', '', 99.96, 0, 0, 0),
(96, '', 'Victor Baldea', '-', 'Baldea', 'CAMARIN', 'Male', 'Helper', '0000-00-00', 537, '0000-00-00', '', '', '', '', 65.64, 0, 0, 0),
(97, '', 'Arnel Bartolome', '-', 'Bartolome', 'CAMARIN', 'Male', 'Helper', '0000-00-00', 537, '0000-00-00', '', '', '', '', 64.44, 0, 0, 0),
(98, '', 'Allan Bartolome', '-', 'Bartolome', 'CAMARIN', 'Male', 'Helper', '0000-00-00', 500, '0000-00-00', '', '', '', '', 60, 0, 0, 0),
(99, '', 'Elmer Tindoc', '-', 'Tindoc', 'CAMARIN', 'Male', 'Helper', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(100, '', 'Francisco Razon', '-', 'Razon', 'CAMARIN', 'Male', 'Helper', '0000-00-00', 500, '0000-00-00', '', '', '', '', 60, 0, 0, 0),
(101, '', 'Peter Taborada', '-', 'Taborada', 'CAAMRIN', 'Male', 'Helper', '0000-00-00', 505, '0000-00-00', '', '', '', '', 60.6, 0, 0, 0),
(102, '', 'William Ortiz', '-', 'Ortiz', 'Driver', 'Male', 'Driver', '0000-00-00', 537, '0000-00-00', '', '', '', '', 64.44, 0, 0, 0),
(103, '', 'Warlito Lucban', '-', 'Lucban', 'Driver ', 'Male', 'Driver', '0000-00-00', 537, '0000-00-00', '', '', '', '', 64.44, 0, 0, 0),
(104, '', 'Gilbert Santiago', '-', 'Santiago', 'Driver', 'Male', 'Driver', '0000-00-00', 537, '0000-00-00', '', '', '', '', 64.44, 0, 0, 0),
(105, '', 'Rico Cuyob', '-', 'Cuyob', 'MLQ', 'Male', 'MLQ', '0000-00-00', 800, '0000-00-00', '', '', '', '', 96, 0, 0, 0),
(106, '', 'Monico Tejero', '-', 'Tejero', 'MLW', 'Male', 'MLQ', '0000-00-00', 600, '0000-00-00', '', '', '', '', 72, 0, 0, 0),
(107, '', 'Marlou Tajero', '-', 'Tajero', 'MLQ', 'Male', 'MLQ', '0000-00-00', 600, '0000-00-00', '', '', '', '', 72, 0, 0, 0),
(108, '', 'Mark Anthony Tajero', '-', 'Tajero', 'MLQ', 'Male', 'MLQ', '0000-00-00', 600, '0000-00-00', '', '', '', '', 72, 0, 0, 0),
(109, '', 'Nelson Gumela', '-', 'Gumela', 'MLQ', 'Male', 'MLQ', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(110, '', 'Ain Malazarte', '-', 'Malazarte', 'MLQ', 'Male', 'MLQ', '0000-00-00', 400, '0000-00-00', '', '', '', '', 48, 0, 0, 0),
(111, '', 'Rodrigo Rivo', '-', 'Rivo', 'BOCAUE', 'Male', 'Bocaue', '0000-00-00', 1000, '0000-00-00', '', '', '', '', 120, 0, 0, 0),
(112, '', 'Jelbert Latras', '-', 'Latras', 'BOCAUE', 'Male', 'Bocaue', '0000-00-00', 600, '0000-00-00', '', '', '', '', 72, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE IF NOT EXISTS `payroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `firstname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `mi` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `position` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `location` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `salary_rate` float NOT NULL,
  `payperiod` varchar(120) COLLATE latin1_general_ci NOT NULL,
  `dayswork` int(4) NOT NULL,
  `ot_hours` int(5) NOT NULL,
  `ot_pay` float(7,2) NOT NULL,
  `allowance` float(8,2) NOT NULL,
  `holesPerWeek` float(6,2) NOT NULL,
  `adjustment` float(8,2) NOT NULL,
  `wtax` float NOT NULL,
  `sss` float NOT NULL,
  `pagibig` float NOT NULL,
  `philhealth` float NOT NULL,
  `tot_ded` float NOT NULL,
  `netpay` float NOT NULL,
  `paydate` date NOT NULL,
  `subtotal` float NOT NULL,
  `cashadvance` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`id`, `lastname`, `firstname`, `mi`, `position`, `location`, `salary_rate`, `payperiod`, `dayswork`, `ot_hours`, `ot_pay`, `allowance`, `holesPerWeek`, `adjustment`, `wtax`, `sss`, `pagibig`, `philhealth`, `tot_ded`, `netpay`, `paydate`, `subtotal`, `cashadvance`) VALUES
(11, '', 'Michael Soposo', '', 'Helper', 'Malabon Sports Complex', 650, '2//2020 - 2/07/2020', 12, 4, 325.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 8125, '2021-02-07', 7800, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payroll_master`
--

CREATE TABLE IF NOT EXISTS `payroll_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `firstname` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `mi` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `position` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `location` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `salary_rate` float NOT NULL,
  `payperiod` varchar(120) COLLATE latin1_general_ci NOT NULL,
  `dayswork` int(4) NOT NULL,
  `ot_hours` int(5) NOT NULL,
  `ot_pay` float(7,2) NOT NULL,
  `allowance` float(8,2) NOT NULL,
  `holesPerWeek` float(6,2) NOT NULL,
  `adjustment` float(8,2) NOT NULL,
  `wtax` float NOT NULL,
  `sss` float NOT NULL,
  `pagibig` float NOT NULL,
  `philhealth` float NOT NULL,
  `tot_ded` float NOT NULL,
  `netpay` float NOT NULL,
  `paydate` date NOT NULL,
  `subtotal` float NOT NULL,
  `cashadvance` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=58 ;

--
-- Dumping data for table `payroll_master`
--

INSERT INTO `payroll_master` (`id`, `lastname`, `firstname`, `mi`, `position`, `location`, `salary_rate`, `payperiod`, `dayswork`, `ot_hours`, `ot_pay`, `allowance`, `holesPerWeek`, `adjustment`, `wtax`, `sss`, `pagibig`, `philhealth`, `tot_ded`, `netpay`, `paydate`, `subtotal`, `cashadvance`) VALUES
(18, '', 'Elesio Domalina', '', '', 'Malabon Sports Complex', 650, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4550, '2020-07-17', 4550, 0),
(12, '', 'Romeo Ibale, Jr', '', '', 'Circulo Verde', 650, '7/11/2020 - 7/17/2020', 7, 12, 975.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 5525, '2020-07-17', 4550, 0),
(13, '', 'Gerald Nitullano', '', '', 'Circulo Verde', 450, '7/11/2020 - 7/17/2020', 7, 12, 675.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3825, '2020-07-17', 3150, 0),
(14, '', 'Jonie Isag', '', '', 'Circulo  Verde', 400, '7/11/2020 - 7/17/2020', 7, 12, 600.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3400, '2020-07-17', 2800, 0),
(15, '', 'Marcelino Rupin', '', '', 'Circulo Verde', 400, '7/11/2020 - 7/17/2020', 7, 12, 600.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3400, '2020-07-17', 2800, 0),
(16, '', 'Michael Virden', '', '', 'Circulo Verde', 350, '7/11/2020 - 7/17/2020', 7, 12, 525.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2975, '2020-07-17', 2450, 0),
(17, '', 'Daniel Senobio', '', '', 'Circulo Verde', 550, '7/11/2020 - 7/17/2020', 7, 12, 825.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4675, '2020-07-17', 3850, 0),
(19, '', 'Sem Barison', '', '', 'Malabon Sports Complex', 650, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4550, '2020-07-17', 4550, 0),
(20, '', 'Eric Cabca', '', '', 'Malabon Sports Complex', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2800, '2020-07-17', 2800, 0),
(21, '', 'Ronald Rabaca', '', '', 'Malabon Sports Complex', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2800, '2020-07-17', 2800, 0),
(22, '', 'Alvin Santelices', '', '', 'Malabon Sports Complex', 400, '7/11/2020 - 7/17/2020', 7, 4, 200.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 2800, 0),
(23, '', 'Nappy Nacar', '', '', 'Malabon Sports Complex', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2800, '2020-07-17', 2800, 0),
(24, '', 'Aldren Wares', '', '', 'Malabon Sports Complex', 350, '7/11/2020 - 7/17/2020', 7, 1, 43.75, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2493.75, '2020-07-17', 2450, 0),
(25, '', 'Ronnie Marapoc', '', '', 'Malabon Sports Complex', 400, '7/11/2020 - 7/17/2020', 7, 1, 50.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2850, '2020-07-17', 2800, 0),
(26, '', 'Michael Soposo', '', '', 'Malabon Sports Complex', 650, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 700.00, 0, 0, 0, 0, 0, 5250, '2020-07-17', 4550, 0),
(27, '', 'John Erwin Barison', '', '', 'Malabon Sports Complex', 350, '7/11/2020 - 7/17/2020', 7, 3, 131.25, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2581.25, '2020-07-17', 2450, 0),
(28, '', 'Jerwin Seposo', '', '', 'Malabon Sports Complex', 350, '7/11/2020 - 7/17/2020', 6, 4, 175.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2275, '2020-07-17', 2100, 0),
(29, '', 'Wilmar Soposo', '', '', 'Malabon Sports Complex', 350, '7/11/2020 - 7/17/2020', 7, 1, 43.75, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2493.75, '2020-07-17', 2450, 0),
(30, '', 'Jose Lunar Navarro', '', '', 'Riverside', 600, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4200, '2020-07-17', 4200, 0),
(31, '', 'Joseph Ansuyon', '', '', 'Riverside', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 200.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 2800, 0),
(32, '', 'Richard Ansuyon', '', '', 'Riverside', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 200.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 2800, 0),
(33, '', 'Ronald Puod', '', '', 'Riverside', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 200.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 2800, 0),
(34, '', 'Joey Ansuyon', '', '', 'Riverside', 400, '7/11/2020 - 7/17/2020', 7, 0, 0.00, 0.00, 0.00, 200.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 2800, 0),
(35, '', 'Jessie Andrada', '', '', 'PASAY', 500, '7/11/2020 - 7/17/2020', 6, 10, 625.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3625, '2020-07-17', 3000, 0),
(36, '', 'Ivan Ramos', '', '', 'PASAY', 500, '7/11/2020 - 7/17/2020', 6, 8, 500.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3500, '2020-07-17', 3000, 0),
(37, '', 'Joevanie Inday', '', '', 'PASAY', 650, '7/11/2020 - 7/17/2020', 6, 10, 812.50, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4712.5, '2020-07-17', 3900, 0),
(38, '', 'Ruel Misagal', '', '', 'PASAY', 750, '7/11/2020 - 7/17/2020', 6, 10, 937.50, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 5437.5, '2020-07-17', 4500, 0),
(39, '', 'Arnold Caniete', '', '', 'PASAY', 500, '7/11/2020 - 7/17/2020', 6, 6, 375.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3375, '2020-07-17', 3000, 0),
(40, '', 'Ernesto Cruz', '', '', 'BACK HOE', 833.34, '7/11/2020 - 7/17/2020', 6, 10, 1041.67, 1000.00, 0.00, 0.00, 0, 0, 0, 0, 600, 6441.71, '2020-07-17', 5000.04, 600),
(41, '', 'Victor Baldea', '', '', 'CAMARIN', 537, '7/11/2020 - 7/17/2020', 6, 4, 268.50, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3490.5, '2020-07-17', 3222, 0),
(42, '', 'Arnel Bartolome', '', '', 'CAMARIN', 537, '7/11/2020 - 7/17/2020', 6, 11, 738.38, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3960.38, '2020-07-17', 3222, 0),
(43, '', 'Allan Bartolome', '', '', 'CAMARIN', 500, '7/11/2020 - 7/17/2020', 6, 8, 500.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3500, '2020-07-17', 3000, 0),
(44, '', 'Elmer Tindoc', '', '', 'CAMARIN', 400, '7/11/2020 - 7/17/2020', 6, 19, 925.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3325, '2020-07-17', 2400, 0),
(45, '', 'Francisco Razon', '', '', 'CAMARIN', 500, '7/11/2020 - 7/17/2020', 6, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 3000, 0),
(46, '', 'Peter Taborada', '', '', 'CAAMRIN', 505, '7/11/2020 - 7/17/2020', 1, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 505, '2020-07-17', 505, 0),
(47, '', 'William Ortiz', '', '', 'Driver', 537, '7/11/2020 - 7/17/2020', 6, 18, 1208.25, 378.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4808.25, '2020-07-17', 3222, 0),
(48, '', 'Warlito Lucban', '', '', 'Driver ', 537, '7/11/2020 - 7/17/2020', 6, 14, 939.75, 378.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4539.75, '2020-07-17', 3222, 0),
(49, '', 'Gilbert Santiago', '', '', 'Driver', 537, '7/11/2020 - 7/17/2020', 6, 15, 973.31, 378.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4573.31, '2020-07-17', 3222, 0),
(50, '', 'Rico Cuyob', '', '', 'MLQ', 800, '7/11/2020 - 7/17/2020', 5, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4000, '2020-07-17', 4000, 0),
(51, '', 'Monico Tejero', '', '', 'MLW', 600, '7/11/2020 - 7/17/2020', 6, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3600, '2020-07-17', 3600, 0),
(52, '', 'Marlou Tajero', '', '', 'MLQ', 600, '7/11/2020 - 7/17/2020', 6, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3600, '2020-07-17', 3600, 0),
(53, '', 'Mark Anthony Tajero', '', '', 'MLQ', 600, '7/11/2020 - 7/17/2020', 5, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 3000, '2020-07-17', 3000, 0),
(54, '', 'Nelson Gumela', '', '', 'MLQ', 400, '7/11/2020 - 7/17/2020', 3, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 100, 1100, '2020-07-17', 1200, 100),
(55, '', 'Ain Malazarte', '', '', 'MLQ', 400, '7/11/2020 - 7/17/2020', 2, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 800, '2020-07-17', 800, 0),
(56, '', 'Rodrigo Rivo', '', '', 'BOCAUE', 1000, '7/11/2020 - 7/17/2020', 4, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 4000, '2020-07-17', 4000, 0),
(57, '', 'Jelbert Latras', '', '', 'BOCAUE', 600, '7/11/2020 - 7/17/2020', 4, 0, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, 0, 0, 2400, '2020-07-17', 2400, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchases_backup`
--

CREATE TABLE IF NOT EXISTS `purchases_backup` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `or_number` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `taxpayers_tin` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `cust_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `address` text COLLATE latin1_general_ci NOT NULL,
  `items` text COLLATE latin1_general_ci NOT NULL,
  `description` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `purchase_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax_input` decimal(15,2) NOT NULL,
  `grosspurchase` decimal(15,2) NOT NULL,
  `paymentmode` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `checknumber` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `delivery_date` date NOT NULL,
  `person_in_charge` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `remarks` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=247 ;

--
-- Dumping data for table `purchases_backup`
--

INSERT INTO `purchases_backup` (`id`, `or_number`, `taxpayers_tin`, `cust_name`, `address`, `items`, `description`, `purchase_date`, `amount`, `tax_input`, `grosspurchase`, `paymentmode`, `checknumber`, `delivery_date`, `person_in_charge`, `remarks`) VALUES
(10, '56151', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'Diesel Fuel', '2020-06-20', '2638.00', '359.64', '2997.00', 'Cash', '', '0000-00-00', 'office', 'Paid Purchases'),
(9, '55769', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'Diesel Fuel', '2020-06-11', '2816.00', '384.00', '3200.00', 'Cash', '', '0000-00-00', 'Office', 'Paid Purchases'),
(11, '55553', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'Diesel', '2020-06-06', '2746.00', '374.40', '3120.00', 'Cash', '', '0000-00-00', 'Office', 'Paid Purchases'),
(12, '56006', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'Diesel', '2020-06-17', '2992.00', '408.00', '3400.00', 'Cash', '', '0000-00-00', 'Office', 'Paid Purchases'),
(13, '000-51170403', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur hi-way cor. University Ave., Potrero, Malabon City', '', 'Diesel fuel', '2020-06-13', '44.64', '5.36', '50.00', 'Cash', '', '0000-00-00', 'office', 'Paid Purchases'),
(14, '0001540455', '215-204-294-000', 'FCHUA GAS STATION', '2882 F. B. Harrison cor. Cuneta St. Pasay City', '', 'Fuel', '2020-06-23', '89.29', '10.71', '100.00', 'Cash', '', '0000-00-00', 'office', 'Paid Purchases'),
(15, '000-SI#631361', '006-333-265-001', 'BBB SHELL SERVICE STATION', '230 MC. Arthur hi-way, Karuhatan, Valenzuela City', '', '16 FSDiesel 21.149 L x 32.62', '2020-06-05', '615.96', '73.92', '689.88', 'Cash', '', '0000-00-00', 'office', 'Paid Purchases'),
(16, '000-51180960', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur Hi-way cor. University Ave., Potrero, Malabon City', '', 'Diesel fuel', '2020-06-25', '1785.71', '214.29', '2000.00', 'Cash', '', '0000-00-00', 'office', 'Paid Purchases'),
(17, '000-SI172934', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur Hi-way cor. University Ave., Potrero, Malabon City', '', 'Diesel fuel', '2020-06-16', '89.29', '10.71', '100.00', 'Cash', '', '0000-00-00', '', 'Paid Purchases'),
(18, '000-si#633642', '006-333-265-001', 'BBB SHELL SERVICE STATION', '230 Mc Arthur Hi-way, Karuhatan, Velenzuela City', '', 'diesel fuel', '2020-06-08', '678.35', '81.40', '759.75', 'Cash', '', '0000-00-00', '', 'Paid Purchases'),
(19, '000-SI#012757', '006-333-265-001', 'BBB SHELL SERVICE STATION', '230 Mc. Arthur Hi-way, Karuhatan, Velenzuela City', '', 'Diesel fuel', '2020-06-08', '122.32', '14.68', '137.00', 'Cash', '', '0000-00-00', '', 'Paid Purchases'),
(20, '001-SI#254790', '152-088-724-007', 'XTRAWEALTH GASOLINE STATION', '705 Gov. Pascual Avenue, Potrero, Malabon City', '', 'diesel fuel', '2020-06-13', '53.57', '6.43', '60.00', 'Cash', '', '0000-00-00', '', 'Paid Purchases'),
(29, 'SI#21670', '238-354-817-000', 'WAKAS FUEL STATION', 'Wakas, Bocaue, Bulacan', '', 'Diesel Fuel', '2020-06-22', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(30, '1001300283380', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', 'Bluel Deiesel', '2020-06-23', '452.04', '54.24', '506.28', '', '', '0000-00-00', '', 'Paid Purchases'),
(23, '000-SI045751', '103-766-072-000', 'GRACE PARK SHELL SERVICE STATION', '249 Rizal Ave. Ext. Grace Park, Caloocan City', '', 'diesel fuel', '2020-06-25', '89.29', '10.71', '100.00', 'Cash', '', '0000-00-00', '', 'Paid Purchases'),
(25, '0000000000023920', '324-471-055-000', 'HONEY MART', '1021 Pablo Ocampo st., cor Arellano St., Malate, Manila', '', 'Arabica, Mocha, Demisoda', '2020-06-16', '479.46', '57.54', '537.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(47, '151876', '009-383-181-000', 'RICHSTAR FUEL STATION COMPANY', '1035 EDSA, Malibay Barangay 182 Pasay City', '', 'diesel fuel', '2020-06-18', '892.85', '107.15', '1000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(27, '000-SI#668864', '005-241-158-005', 'SHELL C5 HERITAGE SERVICE STATION', 'Lot 1 Circumferential road C-5, Heritage Park, Pinagsama, Taquig City', '', 'Diesel Fuel', '2020-06-09', '1964.35', '235.72', '2200.07', '', '', '0000-00-00', '', 'Paid Purchases'),
(31, '1001300281819', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', 'Blue Diesel', '2020-06-19', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(32, '1001300281393', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', 'Blue Diesel', '2020-06-18', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(33, '1001300281379', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', 'Blue Cas95 ', '2020-06-18', '44.64', '5.36', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(34, '1001300280946', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', 'Blue cast 95 ', '2020-06-17', '44.64', '5.36', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(35, '1001300281082', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', 'blue diesel', '2020-06-17', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(36, '101974110301', '000-388-474-0007', 'MERCURY DRUG', 'No.72 Pio Valenzuela st., Marulas, Valenzuela City', '', 'medicine', '2020-06-17', '28.13', '3.37', '31.50', '', '', '0000-00-00', '', 'Paid Purchases'),
(37, '101972156351', '000-388-474-0007', 'MERCURY DRUG', 'No.72 Pio Valenzuela st., Marulas, Valenzuela City', '', 'thermo dig medic', '2020-06-17', '357.14', '42.86', '400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(38, '04129', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'Fuel', '2020-06-22', '321.61', '38.59', '360.20', '', '', '0000-00-00', '', 'Paid Purchases'),
(39, '04159', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'dsl techron', '2020-06-22', '321.61', '38.59', '360.20', '', '', '0000-00-00', '', 'Paid Purchases'),
(40, '03911', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'Diesel fuel', '2020-06-20', '401.61', '48.19', '449.80', '', '', '0000-00-00', '', 'Paid Purchases'),
(41, '03362', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'Dsl techron', '2020-06-16', '1339.29', '160.71', '1500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(42, '03778', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'Dsl techron', '2020-06-19', '660.67', '79.28', '739.95', '', '', '0000-00-00', '', 'Paid Purchases'),
(43, '03270', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel techron', '2020-06-15', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(44, '000851127', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', 'premium fuel', '2020-06-27', '5.36', '44.64', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(45, '04723', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel techron', '2020-06-26', '1607.28', '192.87', '1800.15', '', '', '0000-00-00', '', 'Paid Purchases'),
(46, '0040261', '008-653-388-001', 'REVULTRON DISTRIBUTORS INC.', '38 Espiritu St., Tinajeros, Malabon City', '', 'trekker, ep2', '2020-06-26', '7964.43', '935.57', '8900.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(48, '13375', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', 'Washer', '2020-06-29', '61.60', '8.40', '70.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(49, '13376', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', 'flat washer', '2020-06-29', '98.56', '13.44', '112.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(50, '56290', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', 'nuts', '2020-06-05', '2151.79', '258.21', '2410.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(51, '4369', '346-467-374-000', 'GALAXY PAINT STATION', '182 Mc Arthur highway, Brgy. Karuhatan Dist. 2, Valenzuela City', '', 'O Black', '2020-06-16', '464.28', '55.72', '520.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(52, '9117', '202-182-159-000', 'ARKENSTAR ENTERPRISES', '956 Sabino Padilla Street, Brgy. 295 Zone 028 Binondo, Manila', '', 'lit fuel', '2020-06-23', '3080.00', '420.00', '3500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(53, '218465', '007-653-881-000', 'GOLDEN SCREW CENTER CORPORATION', '158 Mc Arthur Highway, Potrero, Malabon City', '', 'bolt type rubber caster', '2020-06-06', '321.43', '38.57', '360.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(54, '144026', '200-871-429-001', 'SIMPLEX INDUSTRIAL CORPORATION', '81-83 4th ave cor. Rizal ave. Grace Park, Caloocan City', '', 'ply micron set', '2020-06-03', '3526.79', '423.21', '3950.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(55, '420113', '000-330-865-003', 'UNITED BEARING INDUSTRIAL CORP', '1607 Rizal ave. Ext., Brgy 68 Zone 6, District II, Grace Park, Caloocan City', '', 'ENL', '2020-06-20', '192.86', '23.14', '216.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(56, '0108429', '200-871-429-001', 'SIMPLEX INDUSTRIAL CORPORATION', '81-83 4th ave cor. Rizal ave. Grace Park, Caloocan City', '', 'ply loc ucl set', '2020-06-23', '6428.57', '771.43', '7200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(57, '165903', '223-870-526-000', 'PRINCETON MARKETING', '233 J. Teodoro St. cor. Susano St, Brgy 55 Zone 5, Dist II, Caloocan City', '', 'ode c. green', '2020-06-05', '892.85', '107.15', '1000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(58, '297164', '913-374-355-000', 'JACOB INDUSTRIAL & MILL SUPPLY', '235-237 Rizal Ave. Ext Caloocan City', '', 'koten pw-315', '2020-06-05', '4464.29', '535.71', '5000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(59, '0040162', '008-653-388-001', 'REVULTRON DISTRIBUTORS INC.', '38 Espiritu St., Tinajeros, Malabon City', '', 'GEP 140', '2020-06-19', '8214.29', '985.71', '9200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(60, '0000416607', '117-035-104-000-', 'D. MENDOZA STORE', '6 Road 1 San Miguel Heights, Marulas, Valenzuela City', '', 'empty sack', '2020-06-23', '31.25', '3.75', '35.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(61, '784718', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', 'stal', '2020-06-20', '132.00', '18.00', '150.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(62, '785121', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', '1 electrode johnson 500amp', '2020-06-22', '264.00', '36.00', '300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(63, '40712', '237-742-075-000', 'MIDLAND and HYDRAULIC COMPONENTS CORPORATION', 'Unit 82 Grace Park CMML complex, 4th ave, Brgy 51 Zone 5 Dist 2, Caloocan City', '', 'O-ring', '2020-06-19', '500.00', '60.00', '560.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(64, '43433', '000-327-109-000', 'CLK SUPERTOOLS DEPOT INC', '315 Dasmarina St. Brgy. 290 Zone 27, Binondo, Manila 1006', '', 'carbon brush', '2020-06-11', '1271.20', '152.55', '1423.75', '', '', '0000-00-00', '', 'Paid Purchases'),
(65, '460717', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '10 roll annealed wire #16m', '2020-06-16', '9821.43', '1178.57', '11000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(66, '50130', '000-297-999-000', 'ACCURATE DIESEL PARTS SUPPLY, INC.', '276 Rizal Ave, Ext. Bet 5th & 6th Ave., Grace Park, Brgy. 113 Zone 10, Dist. 11, Caloocan City', '', 'top gasket', '2020-06-08', '1760.00', '240.00', '2000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(67, '460718', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '2 roll annealed wire #16m', '2020-06-16', '1964.29', '235.71', '2200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(68, '62604', '004-851-083-000', 'SUN PRINCE TBA CORPORATION', '195 F. Roxas St., 8th Avenue, Brgy. 58 Zone 5, Grace Park, Caloocan City', '', 'jp battery 35mf cmd75d31L', '2020-06-20', '4916.71', '583.29', '5500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(69, '50128', '000-297-999-000', 'ACCURATE DIESEL PARTS SUPPLY, INC.', '276 Rizal Ave, Ext. Bet 5th & 6th Ave., Grace Park, Brgy. 113 Zone 10, Dist. 11, Caloocan City', '', 'inj tube', '2020-06-08', '2112.00', '288.00', '2400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(70, '223680', '103-921-117-000', 'JAPAN PARTS TRADING CENTER', '1273 C. M. Recto avenue, Brgy. 260 Zone 24, Sta. Cruz, Manila', '', 'koyo2 ', '2020-06-11', '2321.43', '278.57', '2600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(71, '0728', '008-850-803-000', 'AMO CONCRETE CORPORATION', '357 M. H. del Pilar Street, Maysilo, Malabon City', '', 'ready mix concrete', '2020-06-03', '17500.00', '2100.00', '19600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(72, '0727', '008-850-803-000', 'AMO CONCRETE CORPORATION', '357 M. H. del Pilar Street, Maysilo, Malabon City', '', 'ready concrete mix', '2020-06-03', '27321.40', '3278.57', '30600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(73, '0132317', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', 'shaft, plate', '2020-06-17', '7478.57', '897.43', '8376.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(74, '0132021', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', 'CRShaft', '2020-06-05', '2125.00', '255.00', '2380.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(75, '224007', '103-921-117-000', 'JAPAN PARTS TRADING CENTER', '1273 C. M. Recto avenue, Brgy. 260 Zone 24, Sta. Cruz, Manila', '', '51110 thrust', '2020-06-23', '267.86', '32.14', '300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(76, '461324', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', 'Deformed bar', '2020-06-19', '214392.86', '25727.14', '240120.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(77, '0738', '008-850-803-000', 'AMO CONCRETE CORPORATION', '357 M. H. del Pilar Street, Maysilo, Malabon City', '', 'ready concrete mix', '2020-06-17', '26250.00', '3150.00', '29400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(78, '0737', '008-850-803-000', 'AMO CONCRETE CORPORATION', '357 M. H. del Pilar Street, Maysilo, Malabon City', '', 'ready concrete mix', '2020-06-15', '17500.00', '2100.00', '19600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(79, '0731', '008-850-803-000', 'AMO CONCRETE CORPORATION', '357 M. H. del Pilar Street, Maysilo, Malabon City', '', 'Ready mix concrete 4000 psi @23 days', '2020-06-08', '52500.00', '6300.00', '58800.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(80, '62194', '221-721-260-000', 'WORLDWIDE UPHOLSTERY AND CANVAS TRADING, INC', '695 S. Padilla St., Brgy. 290 Zone 27, Binondo, Manila', '', '6x12 canvas', '2020-06-30', '528.00', '72.00', '600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(81, '20656', '008-300-342-000', 'CHI-CHAY METAL PRODUCTS, INC.', '1700 Laguna Street, Brgy. 347 Zone 35, Dist III, Sta. Cruz, Manila', '', 'Def. Bar 25mm x 9m G60', '2020-06-30', '72862.50', '8743.50', '81606.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(82, '463515', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '6 pcs Channel bar 4 blue', '2020-06-29', '10982.10', '1317.86', '12300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(83, '463669', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '68 pcs deformed bar 12mm x 6 gr 40', '2020-06-30', '10685.70', '1282.29', '11968.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(84, 'OR00008013', '000-100-703-000', 'READYCON TRADING & CONSTRUCTION CORPORATION', '407 A. Rodriguez Ave., Manggahan, Pasig City', '', 'billing invoice BI00008488, 3/16/2020', '2020-06-09', '1633816.96', '196058.04', '1829875.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(85, '000-si185347', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur hi-way cor. University Ave., Potrero, Malabon City', '', 'Diesel fuel', '2020-06-30', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(86, '05242', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'Dsl techron', '2020-06-30', '321.43', '38.57', '360.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(87, '56576', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'diesel fuel', '2020-06-29', '2704.24', '368.76', '3073.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(88, '77323', '236-107-498-004', 'M POWER GAS STATION', 'Wakas, Bocaue, Bulacan', '', 'premium gas', '2020-06-15', '176.00', '24.00', '200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(89, '782850', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', 'Cap 1/2', '2020-06-12', '154.00', '21.00', '175.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(90, '746150', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', 'CI pipe, Cr pipe.', '2020-06-18', '13745.60', '1874.40', '15620.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(91, '745945', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', 'G.I. pipe', '2020-06-02', '4540.80', '619.20', '5160.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(92, '745936', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', 'gate galvanize', '2020-06-02', '7770.40', '1059.60', '8830.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(93, '8846', '202-182-159-000', 'ARKENSTAR ENTERPRISES', '956 Sabino Padilla Street, Brgy. 295 Zone 028 Binondo, Manila', '', 'assorted materials', '2020-06-10', '57692.80', '7867.20', '65560.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(94, '62156', '221-721-260-000', 'WORLDWIDE UPHOLSTERY AND CANVAS TRADING, INC', '695 S. Padilla St., Brgy. 290 Zone 27, Binondo, Manila', '', '10 x10 84 f/w canvas', '2020-06-26', '748.00', '102.00', '850.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(95, '11008', '216-257-109-000', 'INDUSTRIAL HEATING CORPORATION', '206 D. Cordero St., Bet. 6th & 7th Ave. Grace Park, Caloocan City', '', '1 pc 4140 spline plate\r\n3 pcs 4140 roller', '2020-06-05', '3260.40', '444.60', '3705.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(98, '56995', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'diesel fuel', '2020-07-07', '2916.96', '350.04', '3267.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(99, '56737', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'premium fuel', '2020-07-02', '2743.75', '329.25', '3073.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(100, '57088', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'diesel fuel', '2020-07-09', '1339.29', '160.71', '1500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(101, '57129', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', 'diesel fuel', '2020-07-10', '2744.64', '329.36', '3074.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(102, '57233', '209-313-665-000', 'CRYSTAL FOSSIL MARKETING', '457 Gen. Luna St., Hulong Duhat Malabon City', '', '87 - 86 LTKO', '2020-07-02', '2678.57', '321.43', '3000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(103, '56044', '221-144-177-000-', 'GOLDEN JVC GASOLINE STATION', 'Lot 3 blk 99 Mc. Arthur highway cor. Anonas, Potrero District, Malabon City', '', 'fuel', '2020-07-14', '53.57', '6.43', '60.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(104, '34727', '221-144-177-000-', 'GOLDEN JVC GASOLINE STATION', 'Lot 3 blk 99 Mc. Arthur highway cor. Anonas, Potrero District, Malabon City', '', 'fuel', '2020-07-15', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(105, 'SI193574', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur hi-way cor. University Ave., Potrero, Malabon City', '', '2.018 L @ 49.530 /L', '2020-07-09', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(106, '06259', '115-553-139-000-', 'ROVI PETROLEUM SERVICE CENTER', 'Mc. Arthur Hi-way, Burol 1, Balagtas, Bulacan', '', 'fuel', '2020-07-11', '44.64', '5.36', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(107, '1001300288610', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', '2.300 blueclass 93+ Pump', '2020-07-06', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(108, '1001300287480', '010-058-554-001', 'LUCKY 888 POWER DISTRIBUTORS CORP', 'Mac Arthur Highway, Wakas, Bocaue, Bulacan', '', '1.680 Bluegas 98+', '2020-07-03', '178.57', '21.43', '200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(109, '000858834', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', 'diesel 75.034 L @34.56', '2020-07-13', '2315.34', '277.84', '2593.18', '', '', '0000-00-00', '', 'Paid Purchases'),
(110, '000858043', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', 'diesel 28.947 L @ 34.58', '2020-07-11', '924.08', '110.89', '1034.97', '', '', '0000-00-00', '', 'Paid Purchases'),
(111, '000857675', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', '14.468 L @34.56', '2020-07-11', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(112, '000857673', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', 'diesel 14.468 L  @34.56', '2020-07-11', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(113, 'SI#789556', '144-157-054-000', 'CENTENNIAL SHELL SERVICE STATION', '10th Ave., cor. D. Aquino St., Grace Park, Caloocan City', '', 'FS diesel 13.048L @38.32', '2020-07-07', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(114, 'SI#167834', '107-935-465-000', 'JOMEN SHELL SERVICE STATION', 'KM 17 Mc. Arthur Hi-way, Banga, Meycauayan, Bulacan', '', 'FSGasoline 1.905 L @45.70', '2020-07-04', '77.73', '9.33', '87.06', '', '', '0000-00-00', '', 'Paid Purchases'),
(115, 'SI000288', '238-354-817-000', 'WAKAS FUEL STATION', 'Wakas, Bocaue, Bulacan', '', 'FSGasoline 1.822 L  @43.930', '2020-07-08', '71.46', '8.58', '80.04', '', '', '0000-00-00', '', 'Paid Purchases'),
(116, 'SI000532', '238-354-817-000', 'WAKAS FUEL STATION', 'Wakas, Bocaue, Bulacan', '', 'Diesel fuel', '2020-07-09', '62.64', '7.52', '70.16', '', '', '0000-00-00', '', 'Paid Purchases'),
(117, '05703', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'DslTchron 11.240L @ 35.39', '2020-07-03', '714.33', '85.72', '800.05', '', '', '0000-00-00', '', 'Paid Purchases'),
(118, '05753', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-03', '1071.38', '128.57', '1199.95', '', '', '0000-00-00', '', 'Paid Purchases'),
(119, '05922', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-04', '357.14', '42.86', '400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(120, '06167', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-06', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(121, '06110', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-06', '714.29', '85.71', '800.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(122, '06322', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-07', '178.57', '21.43', '200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(123, '06240', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-07', '321.43', '38.57', '360.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(124, '06457', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-08', '1071.43', '128.57', '1200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(125, '06662', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-09', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(126, '06843', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-10', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(127, '06761', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-10', '357.14', '42.86', '400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(128, '06951', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-11', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(129, '06825', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'diesel fuel', '2020-07-10', '1906.61', '228.79', '2135.40', '', '', '0000-00-00', '', 'Paid Purchases'),
(130, 'SI188446', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur hi-way cor. University Ave., Potrero, Malabon City', '', '1.992 L x 50.180', '2020-07-03', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(131, 'SI#219652', '238-354-817-000', 'WAKAS FUEL STATION', 'Wakas, Bocaue, Bulacan', '', 'Diesel fuel', '2020-07-01', '62.89', '7.55', '70.44', '', '', '0000-00-00', '', 'Paid Purchases'),
(132, 'SI050230', '103-766-072-000', 'GRACE PARK SHELL SERVICE STATION', '249 Rizal Ave. Ext. Grace Park, Caloocan City', '', 'diesel fuel', '2020-07-02', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(133, '000855202', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', 'Diesel fuel', '2020-07-07', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(134, '000854332', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', '42.535L diesel fuel @34.56', '2020-07-07', '1312.50', '157.50', '1470.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(135, '000853976', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', '8.681 L diesel @34.56 ', '2020-07-07', '267.86', '32.14', '300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(136, '000853974', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', '5.498 L diesel @ 34.56', '2020-07-07', '169.64', '20.36', '190.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(137, '000852728', '152-885-512-0002', 'MARY-NOEL FUEL STATION', '27 Lemon St. Arbortowne Village, Brgy. Karuhatan, Valenzuela City', '', '1.965 L diesel @ 50.89', '2020-07-07', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(138, '05568', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'DslTchron 10.959 L @35.59', '2020-07-02', '348.21', '41.79', '390.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(139, '05551', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'dsltchron 10.679 L @35.59', '2020-07-02', '339.33', '40.72', '380.05', '', '', '0000-00-00', '', 'Paid Purchases'),
(140, '05619', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'dsltchron 14.050 L @35.59', '2020-07-02', '446.43', '53.57', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(141, '05466', '226-124-240-000', 'M & A Caltex Service Station', 'Mac Arthur Highway, Bgr. Wakas, Bocaue, Bulacan', '', 'dsltchron 10.116L @35.59', '2020-07-01', '321.43', '38.57', '360.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(142, 'SI#442344', '152-086-724-010', 'PETAWEALTH GASOLINE STATION', 'Mia Rd cor EDSA Triangle, Quezon City', '', '1.982 L @50.450', '2020-07-06', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(143, 'SI192609', '009-488-980-002', 'SKYEWIN PRIME RESOURCES, INC', 'Mc. Arthur hi-way cor. University Ave., Potrero, Malabon City', '', '2.018 L @ 49.530 ', '2020-07-08', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(144, '788714', '130-055-539-000', 'JM OCASLA HARDWARE', '115 Pio Valenzuela st., Marulas, Valenzuela City', '', '1 e-tach, 4 fuse', '2020-07-08', '116.07', '13.93', '130.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(145, '40953', '237-742-075-000', 'MIDLAND and HYDRAULIC COMPONENTS CORPORATION', 'Unit 82 Grace Park CMML complex, 4th ave, Brgy 51 Zone 5 Dist 2, Caloocan City', '', '1 TC-4032c, 1 P-275, 1 BRP-280, 1 P-245, 1 BRP-255', '2020-07-02', '1924.11', '230.89', '2155.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(146, '41013', '237-742-075-000', 'MIDLAND and HYDRAULIC COMPONENTS CORPORATION', 'Unit 82 Grace Park CMML complex, 4th ave, Brgy 51 Zone 5 Dist 2, Caloocan City', '', '1 p-190', '2020-07-04', '156.25', '18.75', '175.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(147, '0254', '438-040-689-000', 'GOLDEN-J HARDWARE', '236 Mc Arthur hi-way, Wakas, Bocaue, Bulacan', '', '20pc 1/2 plywood', '2020-07-11', '12321.43', '1478.57', '13800.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(148, '16554', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '4 set B4 CS MIO X 60/LM, FN', '2020-07-10', '58.04', '6.96', '65.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(149, '16551', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '5 pcs cotting disc 4"', '2020-07-09', '133.93', '16.07', '150.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(150, '16143', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '10 set BH CS MIO x 30 / Nut, FV, LW', '2020-07-07', '68.12', '8.18', '76.30', '', '', '0000-00-00', '', 'Paid Purchases'),
(151, '16141', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '16 sets BH CS Mio x 25 with nut,fw, wl', '2020-07-06', '103.57', '12.43', '116.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(152, '16138', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '10 pcs s/s hose clamp 3/4', '2020-07-04', '109.37', '13.13', '122.50', '', '', '0000-00-00', '', 'Paid Purchases'),
(153, '101976', '131-800-035-000', 'T. DE LEON HARDWARE', 'Wakas, Bocaue, Bulacan', '', '1 pc GI cap #2', '2020-07-03', '125.00', '15.00', '140.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(154, '102000', '131-800-035-000', 'T. DE LEON HARDWARE', 'Wakas, Bocaue, Bulacan', '', '2 pcs Ord GI cap 2 ', '2020-07-07', '125.00', '15.00', '140.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(155, '21111', '160-248-833-000', 'BOCAUE COLOUR GENERAL MERCHANDISING', '283-D Mc Arthur Highway, Binang 1st, Bocaue, Bulacan', '', '1 gal BS QPE cat yellow', '2020-07-03', '482.14', '57.86', '540.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(156, '54738', '160-248-833-001', 'BOCAUE COLOUR GENERAL MERCHANDISING-Branch 1', 'Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '1 gal cat yellow domino', '2020-07-06', '392.86', '47.14', '440.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(157, '54791', '160-248-833-001', 'BOCAUE COLOUR GENERAL MERCHANDISING-Branch 1', 'Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '1 gal cat yellow DM; 1 gal cystal blue DM', '2020-07-07', '785.71', '94.29', '880.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(158, '13412', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', '2 pcs B#44', '2020-07-09', '300.00', '36.00', '336.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(159, '54813', '160-248-833-001', 'BOCAUE COLOUR GENERAL MERCHANDISING-Branch 1', 'Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '1 gal enamel crystal blue', '2020-07-08', '392.86', '47.14', '440.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(160, '54823', '160-248-833-001', 'BOCAUE COLOUR GENERAL MERCHANDISING-Branch 1', 'Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '2 pcs steel brush', '2020-07-09', '89.29', '10.71', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(161, '102029', '131-800-035-000', 'T. DE LEON HARDWARE', 'Wakas, Bocaue, Bulacan', '', '1 pc GI niple 3/4x4\r\n1 pc GI bushin-g 1 x 3/4\r\n1 pc GI red 1/2 x 1', '2020-07-09', '190.18', '22.82', '213.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(162, '102030', '131-800-035-000', 'T. DE LEON HARDWARE', 'Wakas, Bocaue, Bulacan', '', '2 pcs Acme padlock ', '2020-07-09', '357.14', '42.86', '400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(163, '13408', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', '1 pc A 43 MPP', '2020-07-08', '107.14', '12.86', '120.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(164, '13428', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', '2 pcs B 86', '2020-07-09', '625.00', '75.00', '700.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(165, '13426', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', '3 pcs welding rod, NC 100 1/8\r\n8 pcs washers\r\n5 pcs c-stone', '2020-07-09', '438.39', '52.61', '491.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(166, '56498', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '16 pcs 10x50x15 hiss with LW', '2020-07-11', '121.43', '14.57', '136.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(167, '0040661', '008-653-388-001', 'REVULTRON DISTRIBUTORS INC.', '38 Espiritu St., Tinajeros, Malabon City', '', '5 pail AW 68; 2 pail MDIO; 5 pail trekker; 1 pail ATF', '2020-07-16', '22235.71', '2668.29', '24904.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(168, '62793', '102-228-861-000', 'E.S.Q. AUTO SUPPLY', '6 JLB Bldg. Mc Arthur Hi-way, Marulas, Valenzuela City', '', '1 set bendie gear', '2020-07-03', '1339.29', '160.71', '1500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(169, '101957', '131-800-035-000', 'T. DE LEON HARDWARE', 'Wakas, Bocaue, Bulacan', '', '1 pcs nipple 1 1/2 x 5; 1 pc nipple 1 1/2x8; 2 pcs teflon', '2020-07-02', '171.43', '20.57', '192.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(170, '16131', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '4 pcs s/s hose clamp', '2020-07-02', '85.71', '10.29', '96.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(171, '16132', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '15 set BH CS MIO x 35 with FW, LW, Nut; 4 pcs s/s hose clamp 2" 1/2', '2020-07-02', '203.04', '24.37', '227.41', '', '', '0000-00-00', '', 'Paid Purchases'),
(172, '9072', '281-849-924-000', 'FKTL TRADING', '79 Rizal Ave., Ext. brgy 048 Dist 2, Caloocan City', '', '2 AWIO', '2020-07-02', '107.14', '12.86', '120.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(173, '16125', '235-626-823-000', 'BULACAN SCREW LAND CENTER', '927 Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '4 set H.T. CS Mo x 35 w/ Nut, LW', '2020-07-01', '50.11', '6.01', '56.12', '', '', '0000-00-00', '', 'Paid Purchases'),
(174, '54648', '160-248-833-001', 'BOCAUE COLOUR GENERAL MERCHANDISING-Branch 1', 'Mc Arthur Highway, San Juan, Balagtas, Bulacan', '', '1 pc spatula; 1 pc t brush', '2020-07-01', '75.89', '9.11', '85.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(175, '13394', '117-032-853-000', 'BALAGTAS FILIPINO MILL SUPPLY & HARDWARE', 'San Juan, Balagtas, Bulacan', '', '4 sets cylindrical hinge 3/4 dia. 30', '2020-07-01', '107.14', '12.86', '120.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(176, '5965', '109-598-371-000', 'ACHING INDUSTRIAL SALES', '1256 C. M. Recto avenue, Brgy. 294 Zone 28, Binondo, Manila', '', '1 pc pyld Wumm x12', '2020-07-01', '19464.29', '2335.71', '21800.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(177, '504600', '000-331-741-000', 'CLOVER MOTOR SUPPLY, INC.', '948 Benavides St., Brgy 295 Zone 28, Binondo, Manila Philippines, 1006', '', '1 pc cyo5 ', '2020-07-04', '171.43', '20.57', '192.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(178, '10462', '000-023-865-000', 'LING MEI GENERATION CORP.', '1202-1206 C. M. Recto Ave., cor Masangkay St. Brgy. 294 Zone 28, Dist. III, Binondo, Manila', '', '1 pc A I50BND alternator; 1 pcs A M3458 NO', '2020-07-01', '10200.00', '1224.00', '11424.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(179, '50532', '911-634-288-000', 'PVL MARKETING', '141-C Mc Arthur Hi-way, Marulas, Valenzuela City', '', '2 pcs 60 22 fag', '2020-07-07', '10357.14', '1242.86', '11600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(180, '50451', '911-634-288-000', 'PVL MARKETING', '141-C Mc Arthur Hi-way, Marulas, Valenzuela City', '', '6 pcs B57 SKF', '2020-07-02', '1044.64', '125.36', '1170.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(181, '0132800', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', 'Shaft 130mm x 105mm', '2020-07-01', '508.93', '61.07', '570.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(182, '464400', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '6 pcs channel bar 4 blue', '2020-07-03', '10982.14', '1317.86', '12300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(183, '464400', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '10 pcs angle bar 5.0 x 50 x50', '2020-07-03', '6758.93', '811.07', '7570.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(184, '464400', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '4 pcs MS Plate 1/8 2.0', '2020-07-03', '5535.71', '664.29', '6200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(185, '464400', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '6 pcs angle bar 5.0 x 25 x 25', '2020-07-03', '2126.79', '255.21', '2382.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(186, '56436', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '8 pcs HI. TENSILE NUT 24mm x 2.0 pitch', '2020-07-01', '214.29', '25.71', '240.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(187, '56436', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '10 pcs HI.Tensile flat Washer 22mm', '2020-07-01', '160.71', '19.29', '180.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(188, '0133036', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', '1 pc 4140 shaft 45mm x 6 mtrs', '2020-07-08', '3080.36', '369.64', '3450.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(189, '0133036', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', '1 pcs 41410 shaft 70mm x 6 mtrs', '2020-07-08', '7446.43', '893.57', '8340.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(190, '0133036', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', '1 pc 4140 shaft 36mm x 6 mtrs', '2020-07-08', '1758.93', '211.07', '1970.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(191, '0133036', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', '2 pcs 4140 shaft 45mm x 220mm', '2020-07-08', '267.86', '32.14', '300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(192, '0133036', '005-425-287-001', 'GRESON INDUSTRIAL SALES CORPORATION', '100 B. Serrano St., Brgy. 91 Caloocan City', '', '2 pcs 4140 shaft 130mm x 45 mm', '2020-07-08', '553.57', '66.43', '620.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(193, '56477', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '8 pcs Hi-tensile hex cs 1/2x1 w/Nut,LW', '2020-07-07', '78.57', '9.43', '88.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(194, '56477', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '8 pcs Hi-tensile hex cs 1/3x4 w/Nut,LW', '2020-07-07', '60.71', '7.29', '68.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(195, '56477', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '8 pcs Hi-tensile hex cs 1 1/4x1 w/Nut,LW', '2020-07-07', '96.43', '11.57', '108.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(196, '56480', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '8 pcs Hi-tensile hex cs 3/8 x1/2 w/Nut,LW', '2020-07-08', '142.86', '17.14', '160.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(197, '556480', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '1 pc Hi-tensile hex cs 20mx 4 w/Nut,LW', '2020-07-08', '53.57', '6.43', '60.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(198, '56480', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '100 pcs cotter pin 3/16 x 1/4', '2020-07-08', '491.07', '58.93', '550.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(199, '215951', '121-655-188-000', 'TESLAR TRADING', '38 B Rizal Ave. cor. 1st Ave. Grace Caloocan City', '', '1 pc wixim illuminated pushbutton LAY-7 22mm, 1 pc push button 22mm', '2020-07-08', '250.00', '30.00', '280.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(200, '49733', '103-901-058-000', 'ARMAN AUTO ELECTRICAL SUPPLY', '1182 Claro M. Recto, Ave., Brgy. 294 Zone 28, Binondo, Manila', '', '1 pc solenoid buld rewind', '2020-07-07', '1607.14', '192.86', '1800.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(201, '21379', '008-300-342-000', 'CHI-CHAY METAL PRODUCTS, INC.', '1700 Laguna Street, Brgy. 347 Zone 35, Dist III, Sta. Cruz, Manila', '', '60 pcs Def. Bar 25mm x 9m G60', '2020-07-08', '63535.71', '7624.29', '71160.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(202, '465610', '277-381-342-000', 'TKL STEEL CORPORATION', '2206-2208 Oroquieta Brgy. 347 Zone 35 District III, Sta. Cruz, Manila', '', '8 pcs Hi-tensile hex cs 1 1/4x1 w/Nut,LW', '2020-07-09', '19375.00', '2325.00', '21700.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(203, '224623', '103-921-117-000', 'JAPAN PARTS TRADING CENTER', '1273 C. M. Recto avenue, Brgy. 260 Zone 24, Sta. Cruz, Manila', '', '6 Pcs bearing 7209', '2020-07-14', '3589.29', '430.71', '4020.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(204, '50645', '911-634-288-000', 'PVL MARKETING', '141-C Mc Arthur Hi-way, Marulas, Valenzuela City', '', '2 PDS WP 208 24 NTN', '2020-07-11', '1339.29', '160.71', '1500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(205, '71114', '207-075-950-000', 'ROSCO MACHINE SHOP & MFG., CORP.', 'No. 88 ITC Compound, Bagbaguin, 1440 Valenzuela City', '', 'C.I. Foot valves 3 L-40%', '2020-07-15', '959.46', '115.14', '1074.60', '', '', '0000-00-00', '', 'Paid Purchases'),
(206, '0', '0', '-', 'n/a', '', 'Mineral water', '2020-07-09', '30.00', '0.00', '30.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(207, '0', '0', '-', 'n/a', '', '2 cnt mineral water', '2020-07-10', '60.00', '0.00', '60.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(208, '0', '0', 'Suliman Vulcanizing shop', 'n/a', '', '3 plat tire, air', '2020-07-10', '500.00', '0.00', '500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(209, '0', '0', '-', 'n/a', '', '1 cnt mineral water', '2020-07-09', '230.00', '0.00', '230.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(210, '11304', '0', 'MJCIN STEEL TRADING', '-', '', '44 pcs assrtd ', '2020-07-08', '24322.00', '0.00', '24322.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(211, '0', '0', '-', 'n/a', '', '1 set carbon, 1pc coild, labor', '2020-07-06', '1600.00', '0.00', '1600.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(212, '1908', '706-567-954-000', 'RCBB AUTO PARTS SUPPLY', 'Mc Arthur Higway, Wakas, Bocaue Bulacan', '', '40 pcs terminal', '2020-07-07', '140.00', '0.00', '140.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(213, '45347', '248-605-569-000', '02ME', '159 Wakas, Bocaue, Bulacan', '', '1 waterplug with clamp', '2020-07-08', '50.00', '0.00', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(214, '1550', '706-567-954-000', 'RCBB AUTO PARTS SUPPLY', 'Mc Arthur Higway, Wakas, Bocaue Bulacan', '', '2 ps b', '2020-07-03', '380.00', '0.00', '380.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(215, '1902', '706-567-954-000', 'RCBB AUTO PARTS SUPPLY', 'Mc Arthur Higway, Wakas, Bocaue Bulacan', '', '2 pc ', '2020-07-04', '740.00', '0.00', '740.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(216, '1917', '706-567-954-000', 'RCBB AUTO PARTS SUPPLY', 'Mc Arthur Higway, Wakas, Bocaue Bulacan', '', '1pc wb40', '2020-07-05', '310.00', '0.00', '310.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(217, '41744', '152-302-201-000', 'RICMER GENERAL MERCHANDISE', '684 B Sto. Cristo St., Brgy. 21 Zone 25, San Nicolas Manila', '', '30 Pcs rami, 1 pc p twine, 2 pcs ', '2020-07-04', '1725.00', '0.00', '1725.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(218, '6160', '245-886-984-000', 'RGJ AUTO PARTS SUPPLY', '2309 T. Mapua St., St. Cruz, Manila', '', 'assrtd', '2020-07-27', '3571.43', '428.57', '4000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(219, '67112', '229-625-166-000', 'RMBELTRAN CORPORATION', '684 Sto. Cristo St., Brgy. 271 Zone 025, Tondo, Manila', '', '300 pcs ramm c salk', '2020-07-06', '1650.00', '0.00', '1650.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(220, '412', '311-954-598-000', 'FERSHIANMAE AUTO REPAIR', '#3003 Gen. T. De Leon Rd., Brgy. Gen. T. De Leon Dist. 2, Valenzuela City 1442', '', 'Started labor ', '2020-07-03', '450.00', '0.00', '450.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(221, '0', '0', '-', '-', '', '1 bosny signal red', '2020-07-08', '100.00', '0.00', '100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(222, '6333', '150-201-602-000', 'ASIATIC BRAKES & CLUTCH CENTER', '9360 A. Bonifacio Ave., Balintawak, Quezon City', '', '1 pcs curr', '2020-07-02', '7000.00', '0.00', '7000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(223, '0', '0', '-', '-', '', '1 box fresh rod', '2020-06-19', '1500.00', '0.00', '1500.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(224, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '1 roll auto wire #10', '2020-07-04', '900.00', '0.00', '900.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(225, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '1 roll auto wire #14', '2020-07-04', '400.00', '0.00', '400.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(226, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '50 pcs eye terminal 3/16', '2020-07-04', '150.00', '0.00', '150.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(227, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '20 pcs eye terminal 5/16', '2020-07-04', '160.00', '0.00', '160.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(228, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '1 pc amp. gauge box', '2020-07-04', '300.00', '0.00', '300.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(229, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '4 pcs electrical tape', '2020-07-04', '160.00', '0.00', '160.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(230, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '10 ft battery cable', '2020-07-04', '1000.00', '0.00', '1000.00', '', '', '0000-00-00', '', 'Paid Purchases');
INSERT INTO `purchases_backup` (`id`, `or_number`, `taxpayers_tin`, `cust_name`, `address`, `items`, `description`, `purchase_date`, `amount`, `tax_input`, `grosspurchase`, `paymentmode`, `checknumber`, `delivery_date`, `person_in_charge`, `remarks`) VALUES
(231, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '2 pcs battery lug', '2020-07-04', '50.00', '0.00', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(232, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '10 pcs battery terminal', '2020-07-04', '450.00', '0.00', '450.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(233, '5518', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '2 pcs oil filter', '2020-07-04', '460.00', '0.00', '460.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(234, '5520', '488-826-578-000', 'REXFORD AUTO SUPPLY', '86 Mc Arthur hi-way brgy Marulas, Dist.2, Valenzuela City', '', '2 pcs ignition switch eagle japan', '2020-07-04', '1100.00', '0.00', '1100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(235, '143955', '107-579-350-00', 'LOCKHEED AUTO SUPPLY', '303 B. Rizal Avenue Ext. Grace Park, Caloocan City', '', '1 pc gauge', '2020-07-08', '44.64', '5.36', '50.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(236, '003436', '0', 'NRWS AUTO PARTS TRADING', '#1 Sampaguita St., Marulas, Valenzuela City', '', '4 terminal', '2020-07-07', '140.00', '0.00', '140.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(237, '67146', '229-625-166-000', 'RMBELTRAN CORPORATION', '684 Sto. Cristo St., Brgy. 271 Zone 025, Tondo, Manila', '', '200 pcs satomo sack', '2020-07-07', '1100.00', '0.00', '1100.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(238, 'SI022716', '006-333-265-001', 'BBB SHELL SERVICE STATION', '230 Mc. Arthur Hi-way, Karuhatan, Velenzuela City', '', 'FSDiesel 26.393L @ 37.890', '2020-07-14', '892.86', '107.14', '1000.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(239, '68732', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '1 pc MS PLATE 19mm x 4 x 20', '2020-07-02', '34107.14', '4092.86', '38200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(240, '68732', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '4 pcs MS Plate 10m x 4 x 20', '2020-07-06', '70839.29', '8500.71', '79340.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(241, '68732', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '1 pc MS Plate 16mm x 4 x 8', '2020-07-06', '11500.00', '1380.00', '12880.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(242, '68733', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '6 pcs Channel bar 5" x 9lbs', '2020-07-06', '17989.29', '2158.71', '20148.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(243, '04151', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '1 pc MS Plate x 4 ft x20ft', '2020-07-06', '34107.14', '4092.86', '38200.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(244, '04151', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '4 pcs MS Plate 10mm x 4ft x 20ft', '2020-07-06', '70839.29', '8500.71', '79340.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(245, '04151', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '1 pc MS Plate 16mm x 4 ft x 8 ft', '2020-07-06', '11500.00', '1380.00', '12880.00', '', '', '0000-00-00', '', 'Paid Purchases'),
(246, '04152', '201-142-218-000', 'WESTMONT INDUSTRIAL SALES INC.', '1169 Soler St., Brgy 293 Zone 28, Binondo, Manila', '', '6 pcs Channel bar 5 inc x 9 lbs.', '2020-07-06', '17989.29', '2158.71', '20148.00', '', '', '0000-00-00', '', 'Paid Purchases');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE IF NOT EXISTS `stocks` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `stock_number` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `stock_name` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `model` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `brand` varchar(80) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci NOT NULL,
  `unit_price` float NOT NULL,
  `quantity` int(5) NOT NULL,
  `remarks` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=47 ;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `stock_number`, `stock_name`, `model`, `brand`, `description`, `unit_price`, `quantity`, `remarks`) VALUES
(5, 'RPW002', 'PIPE WRENCH', '48 INCHES', 'RIGID', '48 INCHES PIPE WRENCH, ', 0, 1, 'Deff - Missing Hook Jaw, Heel Jaw'),
(4, 'RPW001', 'PIPE WRENCH', '48 INCHES', 'RIGID', '48 INCHES PIPE WRENCH -', 0, 1, ' Deff - Missing Hook jaw'),
(6, 'RPW003', 'PICE WRENCH', '48 INCHES', 'RIGID', '48 INCHES PIPE WRENCH, ', 0, 1, 'color red'),
(7, 'RPW004', 'PIPE WRENCH', '48 INCHES', 'RIGID', '48 INCHES PIPE WRENCH, ', 0, 3, 'complete parts'),
(8, 'SPW001', 'PIPE WRENCH', '36 INCHES', 'STANLEY', '36 INCHES PIPE WRENCH, ', 0, 2, 'Deff-Missing Hook jaw, heel jaw'),
(9, 'RPW005', 'PIPE WRENCH', '36 INCHES', 'RIGID', '36 INCHES PIPE WRENCH, ', 0, 4, '(Initially inventoried as 6 pcs. Deff - Missing Hook '),
(10, 'SPW002', 'PIPE WRENCH', '36 INCHES', 'STANLEY', 'STANLEY P36 INCHES PIPE WRENCH ', 0, 4, ''),
(11, 'RPW006', 'PIPE WRENCH', '36 INCHES', 'RIGID', '36 INCHES PIPE WRENCH', 0, 2, ''),
(12, 'RPW007', 'PIPE WRENCH', '36 INCHES', 'RIGID', '36 INCHES PIPE WRENCH ', 0, 1, 'in Bent condition'),
(13, 'SPW003', 'PIPE WRENCH', '36 INCHES', 'STANLEY', '36 INCHES PIPE WRENCH', 0, 4, ''),
(14, 'SPW004', 'PIPE WRENCH', '24 INCHES', 'STANLEY', '24 INCHES PIPE WRENCH, ', 0, 2, 'Deff - Missing Hook '),
(15, 'RPW007', 'PIPE WRENCH', '24 INCHES', 'RIGID', '24 INCHES PIPE WRENCH, ', 0, 3, '2 Pcs were delivered to Andres Malinao'),
(16, 'RPW006', 'PIPE WRENCH', '24 INCHES', 'RIGID', '24 INCHES PIPE WRENCH - ', 0, 1, 'in the shop'),
(17, 'RPW008', 'PIPE WRENCH', '24 INCHES', 'RIGID', '24 INCHES PIPE WRENCH. ', 0, 2, 'Received by: Francis / Gemacon ELF, Delivered to Andres Combate / Malinao'),
(18, 'MD001', 'HAMMER DRILL', '', 'MAKITA', 'Makita Hammer drill', 0, 3, ''),
(19, 'PHD001', 'HAMMER DRILL', '', 'POWERHOUSE', '1 Hammer drill - yellow', 0, 1, ''),
(20, 'MAG001', 'ANGLE GRINDERS', '', 'MAKITA', '1 Makita angle grinder', 0, 1, ''),
(21, 'CT001', 'CUTTING TORCH', '', '', '8 sets cutting torch', 0, 8, '1 set with missing coupling'),
(22, 'TP001', 'Toho Plunger ca', '', 'TOHO', '10 pcs 110mm x 102mm x 45mm x 26mm', 0, 10, ''),
(23, 'TP002', 'Plunger Cap', '', 'TOHO', '88mm x 83mm x 34mm x 26mm', 0, 10, ''),
(24, 'TP003', 'Plunger cap', '', 'TOHO', '128mm x 125mm x 50mm x 38mm', 0, 8, ''),
(25, 'TP004', 'Plunger Cap', '', 'TOHO', '140mm x 136mm x 55mm x 36mm', 0, 1, ''),
(26, 'TP005', 'Plunger Cap', '', 'TOHO', '133mm x 124mm x 54mm x 33mm', 0, 1, ''),
(27, 'TP006', 'Plunger Cap', '', 'TOHO', '126mm x 124mm x 55mm x 32mm', 0, 1, ''),
(28, 'TP007', 'Plunger Cap', '', 'TOHO', '126mm x 122mm x 49mm x 29mm', 0, 1, ''),
(29, 'TP008', 'Plunger Cap', '', 'TOHO', '110mm x 102mm x 45mm x 26mm', 0, 1, ''),
(30, 'TP009', 'Plunger Cap', '', 'TOHO', '88mm x 83mm x 34mm x 26mm', 0, 1, ''),
(31, 'TP010', 'Plunger Cap', '', 'TOHO', '97mm x 96mm x 34mm x 28mm', 0, 1, ''),
(32, 'TP011', 'Plunger Cap', '', 'TOHO', '81mm x 76mm x 36mm x 27mm', 0, 1, ''),
(33, 'TP012', 'Plunger Cap', '', 'TOHO', '80mm x 77mm x 31mm x 27mm', 0, 1, ''),
(34, 'TP013', 'Plunger Cap', '', 'TOHO', '76mm x 70mm x 35mm x 26mm', 0, 1, ''),
(35, 'RC001', 'Royal Cord', '', 'Royal Cord', '35 meters 3.5mm 12/2', 0, 1, ''),
(36, 'RC002', 'Royal cord', '', 'Royal Cord', '57 meters 3.5mm 8/2', 0, 1, '12/2 3.5mm dugtong sa 8/2 3.5mm '),
(37, 'MAG002', 'Angle Grinder', 'MO9020M', 'MAKITA', 'Makita 180mm (7") Angle Grinder', 0, 1, ''),
(38, 'CW-001', 'Combi-Wrench', 'China', 'Generic', 'One Set 11mm to 32mm combination wrench', 0, 1, ''),
(39, 'Stan-Sck', 'Socket Wrench', 'Stanley', 'STANLEY', '1 set (box) 10mm to 32mm socket wrench', 0, 1, ''),
(40, 'EH-001', 'Electrode Holder', 'A3-S', 'JACKSON', 'Jackson Electrode Holder, 500 Amp, 3/8 in\r\ncable cap: 2/0 through 4/0. 30 oz - Alloy', 0, 2, ''),
(41, 'Sol-Ch', 'Solar Charger', '', 'SEMPER', '10 Ampere Solar charge controller', 0, 1, ''),
(42, 'JS-L2', 'SLAC battery', 'TFT12', '', '12 volts, 7amp sealed lead acid battery, 20 hour', 0, 1, ''),
(43, 'ALC-DIS', 'Alcohol dispenser', '', 'GENERIC', 'sensor operated alcohol dispenser', 0, 1, ''),
(44, 'INF-THER', 'UX-A-01', '', 'Generic', 'Non-Contact Infrared Thermometer', 0, 1, ''),
(45, 'HTM6x2', 'Hand Taps', '', 'OSK', 'M16x2 High Quality Hand Taps', 0, 2, ''),
(46, 'ShSP002', '', '', 'SHOWFOU', 'Submersible pump', 0, 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `studentnumber` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `accesslevel` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `birthday` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `squestion` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `answer` varchar(70) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `studentnumber`, `accesslevel`, `birthday`, `squestion`, `answer`) VALUES
(2, 'ariel', 'clemente', '15000759300', 'Admin', '', '', ''),
(10, 'guest', 'g@ll@rd0888', '15002002100', 'Guest', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
