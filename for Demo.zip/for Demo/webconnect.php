<?php 
// == TO ENABLE SESSION VARIABLES IN HOST DOMAIN
//php_flag output_buffering on;

// connection to iManila
// $servername = "75.55.140.10";
// $database = "gabriels_abby01";
// $username = "gabriels_gabriels";
// $password = "gallardocompany1000";

// -- connection to 000webhost.com
// $servername = "localhost";
// $database = "id14219470_abigail";
// $username = "id14219470_abby";
// $password = "Armageddon67!";


$servername = "localhost";
$database = "newa";
$username = "root";
$password = "";

// Create connection

$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

?>
