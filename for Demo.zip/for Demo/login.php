<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style4 {color: #000000}
-->
</style>
</head>

<SCRIPT Language = Javascript>
<!--
function validateMe() {
frm1 = document.form1;
if(frm1.textfield.value == '') {
alert("Please enter your username!");
frm1.textfield.focus();
return false;
}
if(frm1.textfield2.value == '') {
alert("Please enter your password!");
frm1.textfield2.focus();
return false;
}
// next item to be validated
return true;
}
// End -->
</SCRIPT>

<?php
// Your connection to the database
// == TO ENABLE SESSION VARIABLES IN HOST DOMAIN
//php_flag output_buffering on;
@session_start();
include("webconnect.php");

//$servername = "localhost";
//$database = "id14219470_abigail";
//$username = "id14219470_abby";
//$password = "Armageddon67!";

$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// -- The Login button event
if(isset($_POST['Submit'])) {
// -- the POSTING variables from the form textfields
@$username=$_POST['textfield'];
@$password=$_POST['textfield2'];

// -- the evaluation query, to check whether the username and password exists in the table USERS
$sql = "SELECT * FROM users WHERE username ='$username' AND password ='$password' ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
$row1 = mysqli_fetch_assoc($result); 
$_SESSION['username'] = $row1['username'];
$_SESSION['accesslevel'] = $row1['accesslevel'];
?>
<SCRIPT language="JavaScript">
<!--
    location.header="index.php";
//  End -->
</script>			 
<?php
    
} else {
?>

<SCRIPT language="JavaScript">
<!--
    alert("No Record found for that Username and Password.  Please try again!  ");
//  End -->
</script>			 

<?php 
//mysqli_close($conn);
//exit();
 }
}
?>

<body>
<?php if(@$_SESSION['username']=="") { ?>
<form name="form1" action="" method="post" onsubmit="return validateMe(this.textfield.value);">
  <span class="style4"><strong>Username:
  <input name="textfield" type="text" size="10" value="<?php echo @$_SESSION['username']; ?>"/>
&nbsp; Password:</strong> 
  <input name="textfield2" type="password" size="10" value="<?php echo @$_SESSION['password']; ?>"/>
  <input type="submit" name="Submit" value="Login" />
  </span>
</form>
<?php } else { ?>
      <input input="input" class="button" type="button" name="Submit2" value=" Logout " OnClick="vback();"/>

<?php
}
?>
<Script>
function vback() {
   location.href="logout.php"
}
</script>
</body>
</html>
