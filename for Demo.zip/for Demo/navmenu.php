<title>Home - Menu</title>
<style type="text/css">
<!--
.style8 {
	font-size: xx-large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #FFFF00;
}
-->
</style>
</head>
<?php
@session_start();
?>
<style type="text/css">
<!--
#loading2 {
    width: 200px;
    height: 90px;
    background-color: transparent;
    position: absolute;
    left: 326px;
    top: 61px;
    margin-top: -50px;
    margin-left: -100px;
    text-align: center;
}
.style10 {
	color: #000000;
	font-family: Arial, Helvetica, sans-serif;
}
-->
</style>
<body>

  <table width="100%" height="81"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="8%" rowspan="2" align="left" valign="middle" class="style48"><a href="home.php" target="myiframe"><img src="images/2053619615_58667dd6b2.jpeg" width="99" height="86"></a><span class="style1"><span class="style48"></td>
      <td width="60%" height="49" align="left" valign="bottom" class="style48"><a href="home.php" target="myiframe"><span class="style61"><span class="style8"><span class="style10">NEW-A CONSTRUCTION </span></span></span></a></td>
      <td width="32%" align="right" valign="middle" class="style61"><span class="style27">
        <?php  //if(@$_SESSION['accesslevel']=="") { 
		     include("login.php"); 
             // }else { ?>
        <?php //} ?>
      </span></td>
    </tr>
    
    <tr>
      <td height="26" colspan="2" align="right" valign="middle" bgcolor="#FFFFFF" class="style27"><?php include("mainmenu.php"); ?></td>
    </tr>
</table>
