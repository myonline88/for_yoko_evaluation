<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="css.css" type="text/css" />
<script type="text/javascript" src="scripts/dynifs.js"></script> 
<script type="text/javascript" src="scripts/validNum.js"></script> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Gabriel's Eng'g Payroll</title>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style15 {
	color: #FFFF00;
	font-size: 10;
	font-family: Geneva, Arial, Helvetica, sans-serif;
}
body {
	background-image: url();
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style31 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	font-weight: bold;
}
.style35 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style39 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
.style60 {font-size: 10px}
.style65 {font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; }
.style68 {
	color: #FFFF00;
	font-size: 10px;
	font-family: Arial, Helvetica, sans-serif;
}
.style78 {color: #FFFF00}
.style108 {font-family: Geneva, Arial, Helvetica, sans-serif}
.style110 {font-size: 12px}
.style111 {font-family: Geneva, Arial, Helvetica, sans-serif; font-weight: bold; font-size: 12px; }
.style112 {font-size: 10px; font-family: Geneva, Arial, Helvetica, sans-serif;}
.style113 {font-size: 10px; font-family: Geneva, Arial, Helvetica, sans-serif; color: #FFFF00;}
.style129 {color: #FFFFFF}
.style133 {font-family: Arial, Helvetica, sans-serif}
.style136 {font-size: 12}
.style51 {font-size: 12px; font-weight: bold; }
.style71 {font-family: Verdana, Arial, Helvetica, sans-serif; color: #000000; font-weight: bold; font-size: 12px; }
.style141 {font-family: Verdana, Arial, Helvetica, sans-serif; color: #0000FF; font-weight: bold; font-size: 14px; }
.style146 {
	color: #FFFF00;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 12px;
}
.style152 {
	color: #0000FF;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.style153 {font-size: 14px}
.style155 {color: #0000FF}
.style156 {
	color: #FFFF00;
	font-size: 12px;
	font-weight: bold;
}
.style157 {color: #FFFFFF; font-size: 12px; font-weight: bold; }
.style158 {
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style160 {font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold; }
-->
</style>
</head>
<SCRIPT Language = Javascript>
<!--
function validateMe() {
frm1 = document.form2;
if(frm1.textsearch2.value == '') {
alert("Please enter employee name!");
frm1.textsearch2.focus();
return false;
}
if(frm1.textsearch22.value == '') {
alert("Please enter the number of days worked!");
frm1.textsearch22.focus();
return false;
}

// next item to be validated
return true;
}
// End -->
</SCRIPT>

<?php
@session_start();
include("webconnect.php");
//mysqli_select_db($conn, "kellys_database");
$datetoday = date('Y-m-d');
$current_day = date("l", strtotime($datetoday));
$current_month = date("n", strtotime($datetoday));
$current_year = date("Y", strtotime($datetoday));
$month_name = date("F", strtotime($datetoday));
$b_year = date("Y", strtotime($datetoday));
if($current_day == "Tuesday") {
$firstday = date("d", strtotime($datetoday))-1;
}
if($current_day == "Wednesday") {
$firstday = date("d", strtotime($datetoday))-2;
}
if($current_day == "Thursday") {
$firstday = date("d", strtotime($datetoday))-3;
}
if($current_day == "Friday") {
$firstday = date("d", strtotime($datetoday))-4;
}
if($current_day == "Saturday") {
$firstday = date("d", strtotime($datetoday))-5;
}

$lastday = date("d", strtotime($datetoday));


$sql = "Select * from payroll_master order by location, firstname, paydate ASC ";
$result = mysqli_query($conn, $sql);

$sql2 = " SELECT * from payroll ";
$results2 = mysqli_query($conn, $sql2);

// mysql_connect("localhost", "root", "") or die(mysql_error()); 
// mysql_select_db("students") or die(mysql_error());

$dateposted = date('M-d,Y  h:m:s');
//$result = mysql_query(" select * from payroll order by lastname asc");

$sql1 = " select DISTINCT firstname from employees order by firstname asc ";
$results3 = mysqli_query($conn, $sql1);
//$row3 = mysqli_fetch_assoc($results3);
$sql2 = " select DISTINCT firstname from employees order by firstname asc ";
$results4 = mysqli_query($conn, $sql2);
//$row6 = mysqli_fetch_assoc($results4);

// -- codes for SEARCHING 
if(isset($_POST['btnSearch'])) 
{
//$variable1 = $_POST['textsearch'];
//$criteria1 = $_POST['select'];
$variable2 = $_POST['variable2'];
$start_date = $_POST['b_month'] ."/". $_POST['b_day'] ."/". $_POST['b_year2'];
$end_date =   $_POST['b_month2'] ."/". $_POST['b_day2'] ."/". $_POST['b_year2'];
$days_work = $_POST['textsearch22'];
$ca = $_POST['ca'];
$pay_period = $start_date ." - ". $end_date;
$ot_hours = $_POST['ot_hours'];
$allowance = $_POST['allowance'];
$holesPerWeek = $_POST['holesPerWeek'];
$adjustment = $_POST['adjustment'];


//$criteria2 = $_POST['select2'];

if($variable2=="" || $days_work =="") {
?>
   <script language=Javascript>
	<!--
	alert("Please select employee name and number of days work!");
	// End -->
   </script>
<?php
} else {
$sql1 = " select * from employees where firstname = '$variable2' ";
$result2 = mysqli_query($conn, $sql1);
$row = mysqli_fetch_assoc($result2);
		 $fname = $row['firstname'];
		 $mi = $row['mi'];
		 $lname = $row['lastname'];
		 $position = $row['position'];
		 $salary_rate = $row['salary_rate'];
		 $location = $row['address'];
		 $ot_pay = ($salary_rate/8) * $ot_hours;
		 $sub_total = @$days_work * @$salary_rate ;
		 $deduction = $ca;
		 $net_pay = ($sub_total +  $ot_pay + $allowance + $adjustment) - $ca ;
		 $paydate = date("Y-m-d");
		 $emp_name = $fname ." ". $mi .".". $lname;
		 
		 $sql3 = "UPDATE payroll SET firstname = '$fname', cashadvance = '$ca', "
				. " salary_rate = '$salary_rate', position = '$position', "
				. " payperiod = '$pay_period', dayswork = '$days_work', "
				. " subtotal = '$sub_total', ot_hours = '$ot_hours', location = '$location', "
				. " ot_pay = '$ot_pay', allowance = '$allowance', holesPerWeek = '$holesPerWeek', "
				. " adjustment = '$adjustment', tot_ded = '$deduction', netpay = '$net_pay', "
				. " paydate = '$paydate' ";
				
	mysqli_query($conn, $sql3); 
	//$row1 = mysql_fetch_array($results);
	
   $_SESSION['addnew'] = "true";       
 }
  $sql2 = " SELECT * from payroll ";
  $results2 = mysqli_query($conn, $sql2);
}
//-- END of SEARCHING code
//=== being transfering the dummy to the payroll master
if(isset($_POST['Submit1'])) 
{
 if($_SESSION['addnew'] == "true") {
 $sql = "INSERT into payroll_master(firstname,salary_rate,payperiod,dayswork,location,ot_hours,ot_pay, "
 	. " allowance,holesPerWeek,adjustment,subtotal,tot_ded,netpay,paydate,cashadvance) "
 	. " SELECT firstname,salary_rate,payperiod,dayswork,location,ot_hours,ot_pay,allowance, "
	. " holesPerWeek,adjustment,subtotal,tot_ded,netpay,paydate,cashadvance from payroll ";
 mysqli_query($conn, $sql) ;
 
// $sqld = "DELETE from payroll ";
// mysqli_query($conn, $sqld);
 
}
 $_SESSION['addnew'] = "false";       
}

$sql3 = " select * from payroll_master ORDER by paydate, location, firstname desc " ;
$result = mysqli_query($conn, $sql3);
$row2 = mysqli_fetch_assoc($result);

// ===== BEGIN THE DIFFERENT SEARCH
// -- search by employee name 
if(isset($_POST['btnSearch2'])) 
{
$variable2 = $_POST['variable3'];

if($variable2 =="") {
$sql5 = " select * from payroll_master ORDER by location, firstname, paydate desc ";
$result = mysqli_query($conn, $sql5);
$row2 =  mysqli_fetch_assoc($result);

} else {

//$result = mysql_query(" select * from wad311exer2 where studentnumber LIKE '%%$studnum%%' ");
$result = mysqli_query(" select * from payroll_master where firstname = '$variable2' ORDER by paydate DESC") or die(mysql_error());
$result = mysqli_query($conn, $sql5);
if (mysqli_num_rows($result) == 0) {
?>  
<SCRIPT Language=Javascript>
<!--
	alert("Sorry, no record found for that criteria!");
// End -->
</SCRIPT>
<SCRIPT Language=Javascript>
<!--
	history.back();
// End -->
</SCRIPT>

<?php
  $row = mysqli_fetch_assoc($result);
  $customer = $row['lastname'];
  $sinumber = $row['firstname'];  
   }  
 } 
} 

// ============= the combo search
if(isset($_POST['btnSearch3'])) 
{
//$criteria3 = $_POST['criteria2'];
//$variable3 = $_POST['textsearch3'];
$b_year = $_POST['q_year1'];
$b_month = $_POST['q_month1'];

$start_date = $_POST['q_year1'] ."-". $_POST['q_month1'] ."-". $_POST['q_day1'];
$end_date = $_POST['q_year1'] ."-". $_POST['q_month2'] ."-". $_POST['q_day2'];

$s_date1 = $_POST['q_month1'] ."-". $_POST['q_day1'] ."-". $_POST['q_year1'];
$s_date2 = $_POST['q_month2'] ."-". $_POST['q_day2'] ."-". $_POST['q_year2'];

if($b_year =="" || $b_month =="") {

$sql6 = " select * from payroll_master ORDER by paydate desc ";
$result = mysqli_query($conn, $sql6);
$row2 = mysqli_fetch_assoc($result);
} //else {

//$result = mysql_query(" select * from wad311exer2 where studentnumber LIKE '%%$studnum%%' ");
$sql7 = " select * from payroll_master where paydate >='$start_date' AND paydate <='$end_date' order by location, firstname, paydate desc " ;
$result = mysqli_query($conn, $sql7);
$count = mysql_num_rows($result);

if (mysqli_num_rows($result) > 0) {
$row2 = mysqli_fetch_assoc($result);
@$s_date=$row2['paydate'];
@$convert_date=strtotime($s_date);
$month_name = $s_date1 ."-". $s_date2; 
 } else {
 //
 }
} 
// ====== by monthly search
if(isset($_POST['btnSearch4'])) 
{
//$criteria3 = $_POST['criteria2'];
//$variable3 = $_POST['textsearch3'];
$b_month = $_POST['monthly'];
$b_year = $_POST['yearly'];
$c_year = $_POST['monthly'] ."-". $_POST['yearly'];
 

if($c_year =="") {
$result = mysql_query(" select * from payroll_master ORDER by locatin, firstname, paydate desc ") or die(mysql_error());
$row2 = mysql_fetch_array($result);
} //else {

//$result = mysql_query(" select * from wad311exer2 where studentnumber LIKE '%%$studnum%%' ");
$sql8 = " select * from payroll_master where CONCAT(MONTH(paydate),'-',YEAR(paydate)) = '$c_year' order by location, firstname, paydate desc " ;
$reqult = mysqli_query($conn, $sql8);
if (mysqli_num_rows($result) > 0) {
$row2 = mysqli_fetch_array($result);
@$s_date=$row2['paydate'];
@$convert_date=strtotime($s_date);
@$month_name = date("F", mktime(0, 0, 0, $b_month, 10));
 } else {
 //
 }
} 

// ====== by yearly search
if(isset($_POST['btnSearch5'])) 
{
//$criteria3 = $_POST['criteria2'];
//$variable3 = $_POST['textsearch3'];
$b_year = $_POST['yearly2'];
 

if($b_year =="") {
$sql9 = " select * from payroll_master ORDER by paydate desc ";
$result = mysqli_query($conn, $sql9);
$row2 = mysqli_fetch_assoc($result);
} //else {

//$result = mysql_query(" select * from wad311exer2 where studentnumber LIKE '%%$studnum%%' ");
$sql10 = " select * from payroll_master where CONCAT(YEAR(paydate)) = '$b_year' order by location, firstname, paydate desc ";
$reqult = mysqli_query($conn, $sql10);
if (mysqli_num_rows($result) > 0) {
$row2 = mysqli_fetch_assoc($result);

//@$convert_date=strtotime($s_date);
 } else {
 //
 }
} 

?>

<body><center>
  <table width="100%" height="158" border="0" align="center" cellspacing="4" bgcolor="#FFFFFF" valign="top">
  <tr>
    <td width="100%" height="160" align="center" valign="top" bgcolor="#CCCCFF">
        <?php  if(@$_SESSION['accesslevel']!="Admin") { ?>
        <script language=Javascript>
		<!--
			alert("You are not logged -in or you are not authorized to view this page!");
		// End -->
		  </script>
        <script language=Javascript>
		<!--
			history.back();
		// End -->
		  </script>
        <?php } else {  ?>
  <table width="100%" border="0" align="center" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td height="24" colspan="2" align="left" valign="middle" bgcolor="#FFFFFF">&nbsp;&nbsp;
      <?php include("mainmenu.php"); ?>
      <span class="style31">Employee Payroll Preparation</span>    </tr>
  <tr>
    <td width="1231" height="26" align="left" valign="middle" bgcolor="#FFFFFF"><form name="form2" id="form2" method="post" onsubmit="return validateMe(this.textsearch2.value);">
      <span class="style111"> Employee :<font face="Tahoma" size="2">
      <select name="variable2" id="variable2">
	    <option value ="">-</option>
        <?php 
		while($row3 = mysqli_fetch_assoc($results3)) {
		?>
        <option value="<?php echo $row3['firstname']; ?>" selected="selected"><?php echo $row3['firstname']; ?></option>
        <?php } ?>
      </select>
      </font><span class="style133"><font size="2">|  # Days:
        <input name="textsearch22" type="text" id="textsearch22" onkeyup="checkNumber(document.form2.textsearch22)"  size="2" />
  |  O.T. 
  <label>
  <input name="ot_hours" type="text" id="ot_hours" size="2" onkeyup="checkNumber(document.form2.ca)"/>
  </label>
  | C.A.:
  <label>
  <input name="ca" type="text" id="ca" onkeyup="checkNumber(document.form2.ca)" value="0" size="3"/>
  </label>
  |  </font></span></span><span class="style133 style133"><strong><font size="2">Ho</font></strong></span><span class="style133"><strong><font size="2"></font><font size="2">les</font></strong><font size="2">: 
  <label>
  <input name="holesPerWeek" type="text" id="holesPerWeek" onkeyup="checkNumber(document.form2.ca)" value="0" size="2"/>
  </label>
| <strong>Allo</strong>: 
  <label>
  <input name="allowance" type="text" id="allowance" onkeyup="checkNumber(document.form2.ca)" value="0" size="2"/>
  </label> 
  |<strong>Ajd.</strong>: 
  <label>
  <input name="adjustment" type="text" id="adjustment" onkeyup="checkNumber(document.form2.ca)" value="0" size="3"/>
  </label>

| Pay Period</font></span><span class="style111"><font face="Tahoma" size="2">
  <select name="b_month" size="1">
    <option value="<?php echo @$current_month; ?>"><?php echo @$month_name; ?></option>
    <option value="1">Jan</option>
    <option value="2">Feb</option>
    <option value="3">Mar</option>
    <option value="4">Apr</option>
    <option value="5">May</option>
    <option value="6">Jun</option>
    <option value="7">Jul</option>
    <option value="8">Aug</option>
    <option value="9">Sep</option>
    <option value="10">Oct</option>
    <option value="11">Nov</option>
    <option value="12">Dec</option>
  </select>
      </font></span> <font face="Tahoma" size="2">
      <select name="b_day" size="1">
        <option value="<?php echo @$firstday; ?>" selected="selected"><?php echo @$firstday; ?></option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
      </select>
      </font> <span class="style65">to</span><font face="Tahoma" size="2">
      <select name="b_month2" size="1" id="b_month2">
        <option value="<?php echo @$current_month; ?>" selected="selected"><?php echo @$month_name; ?></option>
        <option value="1">Jan</option>
        <option value="2">Feb</option>
        <option value="3">Mar</option>
        <option value="4">Apr</option>
        <option value="5">May</option>
        <option value="6">Jun</option>
        <option value="7">Jul</option>
        <option value="8">Aug</option>
        <option value="9">Sep</option>
        <option value="10">Oct</option>
        <option value="11">Nov</option>
        <option value="12">Dec</option>
      </select>
      <select name="b_day2" size="1" id="b_day2">
        <option value="<?php echo @$lastday; ?>" selected="selected"><?php echo @$lastday; ?></option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
      </select>
      <font face="Times New Roman, Times, serif">
      <select name="b_year2" size="1" id="b_year2">
        <option value="2007">2007</option>
        <option value="2008">2008</option>
        <option value="2009">2009</option>
        <option value="2010">2010</option>
        <option value="2011">2011</option>
        <option value="2012">2012</option>
        <option value="2013">2013</option>
        <option value="2014">2014</option>
        <option value="2015">2015</option>
        <option value="2016">2016</option>
        <option value="2017">2017</option>
        <option value="2018">2018</option>
        <option value="2019">2019</option>
        <option value="2020" selected="selected">2020</option>
        <option value="2021">2021</option>
        <option value="2022">2022</option>
        <option value="2023">2023</option>
        <option value="2024">2024</option>
        <option value="2025">2025</option>
		<option value="2026">2026</option>
        <option value="2027">2027</option>
        <option value="2028">2028</option>
        <option value="2029">2029</option>
        <option value="2030">2030</option>
      </select>
      </font> </font> &nbsp; <font face="Tahoma" size="2">
      <input name="btnSearch" type="submit" id="btnSearch" value="Compute" />
      </font>
    </form>  
    <td width="92" align="right" valign="middle" bgcolor="#FFFFFF" class="style31"><form id="form11" name="form11" method="post" action="">
      <label>
        <input name="Submit1" type="submit" id="Submit1" value="  Save" />
        </label>
    </form>    </td>
  </tr>
</table>
      <center>	
		<?php  // include('pagination.php'); ?>
	
	  <table width="100%" height="61" border="0" cellpadding="1" cellspacing="1" bordercolor="#99CCCC" align="center">
        <tr bgcolor="#000033">
          <td width="134" rowspan="2" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>Employee Name </strong></span></span></td>
          <td width="135" rowspan="2" bgcolor="#000033"><span class="style156">Location</span></td>
          <td width="52" rowspan="2" align="center" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>No. of Days </strong></span></span></td>
          <td width="56" rowspan="2" align="center" valign="middle" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>Salary</strong></span></span><span class="style15 style35 style60"><span class="style108 style110"><strong><br /> 
            Rate </strong></span></span></td>
          <td width="146" rowspan="2" align="center" valign="middle" bgcolor="#000033"><span class="style39 style68"><span class="style111 style110">Payroll </span></span><span class="style113 style60 style35"><strong><span class="style108 style110">Period</span></strong></span></td>
          <td width="50" rowspan="2" align="center" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>O. T <br />
            Hours </strong></span></span><span class="style15 style35 style60"><span class="style108 style110"><strong> </strong></span></span></td>
          <td width="56" rowspan="2" align="center" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>O. T. Pay </strong></span></span></td>
          <td width="66" rowspan="2" align="center" bgcolor="#000033"><span class="style146">Allo<br />
            wance</span></td>
          <td width="54" rowspan="2" align="center" bgcolor="#000033"><div align="center" class="style112 style35 style110"><span class="style113 style60 style35"><strong><span class="style108 style110">Cash</span></strong></span></div>            <span class="style113 style60 style35"><strong><span class="style108 style110"> Adv</span></strong></span></td>
          <td width="60" rowspan="2" align="center" bgcolor="#000033"> <strong><span class="style108 style110 style78">Bonus per Week </span></strong></td>
          <td width="59" rowspan="2" align="center" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>Adjust ment </strong></span></span></td>
          <td width="89" rowspan="2" align="center" bgcolor="#000033"><span class="style113 style60 style35"><strong><span class="style108 style110">Basic Pay </span></strong></span><span class="style113 style60 style35"><strong><span class="style108 style110"> </span></strong></span></td>
          <td width="65" rowspan="2" align="center" bgcolor="#000033"><span class="style15 style35 style60"><span class="style108 style110"><strong>Total</strong></span><br />
          </span><span class="style15 style35 style60"><span class="style108 style110"><strong>Deduction</strong></span></span></td>
          <td width="101" rowspan="2" align="center" bgcolor="#000033"><span class="style113 style60 style35"><strong><span class="style108 style110">Net Pa&nbsp;y</span></strong></span></td>
          <td width="87" rowspan="2" align="center" bgcolor="#000033"><span class="style113 style60 style35"><strong><span class="style108 style110">Pay</span></strong></span><span class="style113 style60 style35"><strong><span class="style108 style110"> Date</span></strong></span></td>
          <td width="68" height="17" bgcolor="#000033"><div align="center" class="style112 style35 style110"><strong><span class="style78">!!!</span></strong></div></td>
        </tr>
        <tr bgcolor="#000033">
          <td width="68" height="14" bgcolor="#000033"><div align="center" class="style112 style35 style110"><strong><span class="style78">!!!</span></strong></div></td>
        </tr>

        <?php
		 //$result2 = mysql_query(" select * from payroll ORDER by lastname asc");
  	 	 $row1 = mysqli_fetch_assoc($results2);
		 
		?>
        <tr bordercolor="#996633" bgcolor="#FFCCFF">
          <td height="21" valign="top" bgcolor="#FFFFFF"><span class="style110 style35"><strong><?php echo $row1['firstname']; ?></strong></span></td>
          <td height="21" valign="top" bgcolor="#FFFFFF"><span class="style158 style35"><?php echo $row1['location']; ?></span></td>
          <td align="center" valign="top" bgcolor="#FFFFFF"><span class="style110 style35"><strong><?php echo $row1['dayswork']; ?></strong></span></td>
          <td align="center" valign="top" bgcolor="#FFFFFF"><span class="style71"><?php echo number_format($row1['salary_rate'],2); ?> </span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style111 style110 style35"><?php echo $row1['payperiod']; ?>&nbsp;</span></td>
          <td align="center" valign="top" bgcolor="#FFFFFF"><span class="style39"><strong><?php echo $row1['ot_hours']; ?></strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style110 style35"><strong><?php echo number_format($row1['ot_pay'],2); ?>&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><strong><span class="style110"><?php echo number_format($row1['allowance'],2); ?></span></strong><span class="style110">&nbsp;</span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style110 style35"><strong><?php echo number_format($row1['cashadvance'],2); ?>&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style110 style35"><strong><?php echo number_format($row1['holesPerWeek'],2); ?>&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style110 style35"><strong><?php echo number_format($row1['adjustment'],2); ?>&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style65 style110 style35"><strong><?php echo number_format($row1['subtotal'],2); ?>&nbsp;&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style60 style35 style65"><strong><?php echo number_format($row1['tot_ded'],2); ?>&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style141 style110 style35"><?php echo number_format($row1['netpay'],2); ?>&nbsp;</span><span class="style65 style35 style153"><strong>&nbsp;</strong></span></td>
          <td align="right" valign="top" bgcolor="#FFFFFF"><span class="style65 style110 style35"><strong><?php echo $row1['paydate']; ?>&nbsp;</strong></span></td>
          <td align="center" valign="top" bgcolor="#FFFFFF"><div align="center" class="style39">
            <span class="style111 style110 style35"><img src="buttons/001_15.png" width="16" height="16" /></span></td>
        </tr>
        <?php
		 }
		?>
         <?php // echo $pagination?>
   </table>
	  <br />	 </td>
  </tr>
  
</table>
  <br />
  <table width="99%" border="0" cellspacing="0" cellpadding="2">
    <tr>
      <td width="28%" height="28" valign="middle" bgcolor="#99CC99"><form id="form3" name="form3" method="post">
          <span class="style51">Search by</span>:<font face="Tahoma" size="2">
          <select name="variable3" id="select3">
            <option value ="">-</option>
            <?php 
			while($row6 = mysqli_fetch_assoc($results4)) {
			?>
            <option value="<?php echo $row6['firstname']; ?>" selected="selected"><?php echo $row6['firstname']; ?></option>
            <?php } ?>
          </select>
          </font>
          <input name="btnSearch2" type="submit" id="btnSearch2" value="GO&gt;" />
      </form></td>
      <td width="20%" align="center" valign="middle" bgcolor="#99CCFF"><form id="form5" name="form5" method="post" >
          <strong> <span class="style71">&nbsp;</span></strong><span class="style71">Monthly</span><font face="Tahoma" size="2">
          <select name="monthly" size="1" id="select">
            <option value="<?php echo @$q_date = date('F', $convert_date); ?>" selected="selected">-</option>
            <option value="1">Jan</option>
            <option value="2">Feb</option>
            <option value="3">Mar</option>
            <option value="4">Apr</option>
            <option value="5">May</option>
            <option value="6">Jun</option>
            <option value="7">Jul</option>
            <option value="8">Aug</option>
            <option value="9">Sep</option>
            <option value="10">Oct</option>
            <option value="11">Nov</option>
            <option value="12">Dec</option>
          </select>
          </font> <font face="Tahoma" size="2"><font face="Times New Roman, Times, serif">
          <select name="yearly" size="1" id="select2">
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020" selected="selected">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
			<option value="2026">2026</option>
			<option value="2027">2027</option>
			<option value="2028">2028</option>
			<option value="2029">2029</option>
			<option value="2030">2030</option>
          </select>
          </font></font>
          <input name="btnSearch4" type="submit" id="btnSearch4" value="Go&gt;" />
      </form></td>
      <td width="13%" align="left" valign="middle" bgcolor="#99CCFF"><form id="form6" name="form6" method="post" >
          <strong> <span class="style71">&nbsp;</span></strong><span class="style71">Yearly</span><font face="Tahoma" size="2"><font face="Times New Roman, Times, serif">
          <select name="yearly2" size="1" id="select4">
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020" selected="selected">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
			<option value="2026">2026</option>
			<option value="2027">2027</option>
			<option value="2028">2028</option>
			<option value="2029">2029</option>
			<option value="2030">2030</option>
          </select>
          </font></font>
          <input name="btnSearch5" type="submit" id="btnSearch5" value="GO&gt;" />
      </form></td>
      <td width="39%" align="left" valign="middle" bgcolor="#CCCCCC"><form id="form7" name="form7" method="post" >
          <span class="style71">&nbsp;From</span>&nbsp; <font face="Tahoma" size="2">
          <select name="q_month1" size="1" id="select7">
            <option value="<?php echo @$q_date = date('F', $convert_date); ?>" selected="selected">-</option>
            <option value="1">Jan</option>
            <option value="2">Feb</option>
            <option value="3">Mar</option>
            <option value="4">Apr</option>
            <option value="5">May</option>
            <option value="6">Jun</option>
            <option value="7">Jul</option>
            <option value="8">Aug</option>
            <option value="9">Sep</option>
            <option value="10">Oct</option>
            <option value="11">Nov</option>
            <option value="12">Dec</option>
          </select>
          <select name="q_day1" size="1" id="select8">
            <option value="" selected="selected">-</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
          </font> <span class="style71">to</span> <font face="Tahoma" size="2">
          <select name="q_month2" size="1" id="select10">
            <option value="<?php echo @$q_date = date('F', $convert_date); ?>" selected="selected">-</option>
            <option value="1">Jan</option>
            <option value="2">Feb</option>
            <option value="3">Mar</option>
            <option value="4">Apr</option>
            <option value="5">May</option>
            <option value="6">Jun</option>
            <option value="7">Jul</option>
            <option value="8">Aug</option>
            <option value="9">Sep</option>
            <option value="10">Oct</option>
            <option value="11">Nov</option>
            <option value="12">Dec</option>
          </select>
          <select name="q_day2" size="1" id="select11">
            <option value="" selected="selected">-</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
          </select>
          <font face="Times New Roman, Times, serif">
          <select name="q_year2" size="1" id="select12">
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
            <option value="2018">2018</option>
            <option value="2019">2019</option>
            <option value="2020" selected="selected">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
			<option value="2026">2026</option>
			<option value="2027">2027</option>
			<option value="2028">2028</option>
			<option value="2029">2029</option>
			<option value="2030">2030</option>
          </select>
          </font></font>
          <input name="btnSearch3" type="submit" id="btnSearch3" value="Go&gt;" />
        &nbsp;
      </form></td>
    </tr>
  </table>

<table width="99%" height="79" border="0" cellpadding="1" cellspacing="1" bordercolor="#99CCCC" align="center">
  <tr bgcolor="#000033">
    <td width="130" rowspan="2" bgcolor="#000000"><span class="style15 style35 style60"><span class="style129 style133 style110"><strong>Employee Name </strong></span></span></td>
    <td width="177" rowspan="2" bgcolor="#000000"><span class="style157">Location</span></td>
    <td width="46" rowspan="2" align="center" bgcolor="#000000"><span class="style15 style35 style60"><span class="style129 style133 style110"><strong>No. of Days </strong></span></span></td>
    <td width="63" rowspan="2" align="center" valign="middle" bgcolor="#000000"><span class="style15 style35 style60"><span class="style108 style110 style129"><strong>Salary<br />
    </strong></span></span><span class="style15 style35 style60"><span class="style129 style133 style110"><strong> Rate </strong></span></span></td>
    <td width="129" rowspan="2" align="center" valign="middle" bgcolor="#000000"><span class="style113 style60 style35"><strong><span class="style129 style133 style110"><span class="style39 style68"><span class="style111 style110 style129">Payroll </span></span>Period</span></strong></span></td>
    <td width="39" rowspan="2" align="center" bgcolor="#000000"><span class="style15 style35 style60"><span class="style108 style110 style129"><strong>O. T </strong></span></span><span class="style15 style35 style60"><span class="style129 style133 style110"><strong><br />
      Hours</strong></span></span></td>
    <td width="54" rowspan="2" align="center" bgcolor="#000000"><span class="style15 style35 style60"><span class="style129 style133 style110"><strong>O.T. Pay</strong></span></span></td>
    <td width="52" rowspan="2" align="center" bgcolor="#000000"><strong><span class="style129 style133 style110">Allo<br />
    wance</span></strong></td>
    <td width="62" rowspan="2" align="center" bgcolor="#000000"><span class="style113 style60 style35"><strong><span class="style129 style133 style110">Cash<br />
Adv</span></strong></span></td>
    <td width="59" rowspan="2" align="center" bgcolor="#000000"><span class="style15 style35 style60"><span class="style129 style133 style110"><strong>Holes Per Week </strong></span></span></td>
    <td width="60" rowspan="2" align="center" bgcolor="#000000"><span class="style15 style35 style60"><span class="style129 style133 style110"><strong>Adjust ment </strong></span></span></td>
    <td width="89" rowspan="2" align="center" bgcolor="#000000"><span class="style113 style60 style35"><strong><span class="style129 style133 style110">Basic Pay </span></strong></span></td>
    <td width="68" rowspan="2" align="center" bgcolor="#000000"><span class="style15 style35 style60"><span class="style108 style110 style129"><strong>Total</strong></span><br />
    </span><span class="style15 style35 style60"><span class="style129 style133 style110"><strong>Deduction</strong></span></span></td>
    <td width="94" height="15" bgcolor="#000000">&nbsp;</td>
    <td width="91" rowspan="2" align="center" bgcolor="#000000"><span class="style113 style60 style35"><strong><span class="style108 style110 style129">Pay</span></strong></span><span class="style113 style60 style35"><strong><span class="style129 style133 style110"> Date</span></strong></span></td>
    <td width="62" bgcolor="#000000"><div align="center" class="style112 style35 style110 style129"><strong>!!!</strong></div></td>
  </tr>
  <tr bgcolor="#000033">
    <td width="94" height="17" align="center" bgcolor="#000000"><span class="style113 style60 style35"><strong><span class="style129 style133 style110">Net Pa&nbsp;y</span></strong></span></td>
    <td width="62" bgcolor="#000000"><div align="center" class="style112 style129 style133 style110"><strong>!!!</strong></div></td>
  </tr>
  <?php
	 //	$result4 = mysql_query(" select * from payroll_master ORDER by lastname asc");
		$totalsalaries = 0;
		$cashadvances = 0;
		$allow = 0;
		$ot_pays = 0;
		$adjusts = 0;
		$subtotals = 0;
  	 	while(@$row2 = mysqli_fetch_assoc( $result )) {	
		$totalsalaries = $totalsalaries + $row2['netpay'];
		$cashadvances = $cashadvances + $row2['cashadvance'];
		$allow = $allow + $row2['allowance'];
		$ot_pays = $ot_pays + $row2['ot_pay'];
		$adjusts = $adjusts + $row2['adjustment'];
		$subtotals = $subtotals + $row2['subtotal'];		
		
				if(@$color == "#EBEAE9") {
		     	@$color = "#D8DFBF";
    			} else {
      			@$color = "#EBEAE9";
    			}			

		?>
		
  <tr bordercolor="#996633" bgcolor="#FFCCFF">
    <td height="21" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style65"><?php echo $row2['firstname']; ?></span></td>
    <td height="21" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><strong><?php echo $row2['location']; ?></strong></td>
    <td align="center" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style160"><?php echo $row2['dayswork']; ?></span></td>
    <td align="center" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style111 style133 style136"><span class="style39"><?php echo number_format($row2['salary_rate'],2); ?></span></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style111 style133 style136"><span class="style110"><?php echo $row2['payperiod']; ?>&nbsp;</span></span></td>
    <td align="center" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style160"><?php echo $row2['ot_hours']; ?></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style110 style35"><strong><?php echo number_format($row2['ot_pay'],2); ?>&nbsp;</strong></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style110 style35"><strong><?php echo number_format($row2['allowance'],2); ?>&nbsp;</strong></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style110 style35"><strong><?php echo number_format($row2['cashadvance'],2); ?>&nbsp;</strong></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style110 style35"><strong><?php echo number_format($row2['holesPerWeek'],2); ?>&nbsp;</strong></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style110 style35"><strong><?php echo number_format($row2['adjustment'],2); ?>&nbsp;</strong></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style60 style65 style133"><span class="style35"><?php echo number_format($row2['subtotal'],2); ?>&nbsp;</span></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style35 style65 style60"><span class="style110"><?php echo number_format($row2['tot_ded'],2); ?>&nbsp;</span></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style60 style65 style108"><span class="style152"><?php echo number_format($row2['netpay'],2); ?>&nbsp;</span></span></td>
    <td align="right" valign="top" bgcolor="<?php echo $color; ?>" class="style111"><span class="style65 style35 style110"><strong><?php echo $row2['paydate']; ?>&nbsp;</strong></span></td>
    <td align="center" valign="top" bgcolor="<?php echo $color; ?>" class="style65"><div align="center" class="style39">        <img src="buttons/001_15.png" width="16" height="16" /></td>
  </tr>
  <?php
		  }
		@mysqli_close($conn);  
		?>
  <?php // echo $pagination?>
  
  <tr bordercolor="#996633" bgcolor="#FFCCFF">
    <td height="21" colspan="2" align="right" valign="top" bgcolor="#CCCCFF" class="style111 style153">TOTALS</td>
    <td align="center" valign="top" bgcolor="#CCCCFF" class="style111">&nbsp;</td>
    <td align="center" valign="top" bgcolor="#CCCCFF" class="style111">&nbsp;</td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111">&nbsp;</td>
    <td align="center" valign="top" bgcolor="#CCCCFF" class="style111">&nbsp;</td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111"><span class="style152 style110 style35"><span class="style110"><?php echo number_format($ot_pays,2); ?>&nbsp;</span></span></td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111 style35 style153">&nbsp;<span class="style155"><?php echo number_format($allow,2); ?></span>&nbsp;</td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111"><span class="style152 style110 style35"><span class="style35 style153"><?php echo number_format($cashadvances,2); ?></span></span> </td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111"><span class="style152 style110 style35">&nbsp;</span></td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111 style35 style153 style35"><span class="style155"><?php echo number_format($adjusts,2); ?></span>&nbsp;</td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111"><span class="style152 style133 style110"><span class="style110 style35"><?php echo number_format($subtotals,2); ?>&nbsp;</span></span></td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111"><span class="style152 style110 style35"><span class="style110"><?php echo number_format($cashadvances,2); ?>&nbsp;</span></span></td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111"><span class="style152"><?php echo number_format($totalsalaries,2); ?>&nbsp;</span></td>
    <td align="right" valign="top" bgcolor="#CCCCFF" class="style111">&nbsp;</td>
    <td align="center" valign="top" bgcolor="#CCCCFF" class="style65">&nbsp;</td>
  </tr>
</table>
</center>
</body>
</html>
